package com.bookingflights.flights.DTO;

import lombok.Data;

@Data
public class GenreDTO {
	
	private Long id;
	private String description;
	private boolean status;
	
	public GenreDTO() {}
	
	public GenreDTO(Long id, String description, boolean status) {	
		this.id = id;
		this.description = description;
		this.status = status;
	}
	
	
}
