package com.bookingflights.flights.service.imp;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.bookingflights.flights.entity.AirplaneCapacity;
import com.bookingflights.flights.repository.AirplaneCapacityRepository;
import com.bookingflights.flights.service.AirplaneCapacityService;

@Service
public class AirplaneCapacityImp implements AirplaneCapacityService{
	
	@Autowired
	AirplaneCapacityRepository airplaneCapacityRepository;

	@Override
	public AirplaneCapacity findById(Long id) {
		Optional<AirplaneCapacity>opt = airplaneCapacityRepository.findById(id);
		return opt.get();
	}

	@Override
	public List<AirplaneCapacity> findAll() {
		
		return airplaneCapacityRepository.findAll();
	}
	
	@Transactional(rollbackOn = {RuntimeException.class})
	@Override
	public AirplaneCapacity save(AirplaneCapacity e) {
		
		return airplaneCapacityRepository.save(e);
	}
	
	@Transactional(rollbackOn = {RuntimeException.class})
	@Override
	public AirplaneCapacity update(AirplaneCapacity e) {
		// TODO Auto-generated method stub
		return airplaneCapacityRepository.save(e);
	}
	
	@Transactional(rollbackOn = {RuntimeException.class})
	@Override
	public void deleteById(Long id) throws Exception {
		airplaneCapacityRepository.deleteById(id);
		
	}

	@Override
	public List<AirplaneCapacity> findByIdAirplanecapacity(Long id) {
		// TODO Auto-generated method stub
		return airplaneCapacityRepository.findByIdAirplanecapacity(id);
	}

}
