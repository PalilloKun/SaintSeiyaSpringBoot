package com.bookingflights.flights.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bookingflights.flights.entity.Location;
import com.bookingflights.flights.response.ExceptionResponse;
import com.bookingflights.flights.service.LocationService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/locations")
public class LocationController {
	
	@Autowired
	LocationService locationService;
	
	 @ApiOperation(value = "Obtener la lista de ubicaciones de los vuelos",
	            notes = "No necesita parametros de entrada",
	            response = List.class,
	            responseContainer = "Location")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontraron las Ubicaciones en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Location.class, responseContainer = "List")})
	@GetMapping
	public ResponseEntity<List<Location>> listar(){
		
		List<Location> lista = locationService.findAll();		
		return new ResponseEntity<List<Location>>(lista, HttpStatus.OK);
	}	
	
	 
	 @ApiOperation(value = "Obtener la ubicacion por su ID ",
	            notes = "Necesita el ID de la ubicacion",
	            response = Location.class,
	            responseContainer = "Location")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro la Ubicacion en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Location.class, responseContainer = "Location")})	
	@GetMapping("/{id}")
	public ResponseEntity <Location> finbyid(@PathVariable("id") Long id){
		
		Location lista = locationService.findById(id);		
		return new ResponseEntity<Location>(lista, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para registrar nuevas Ubicaciones en el sistema ",
	            notes = "Necesita el nombre y id de la region",
	            response = Location.class,
	            responseContainer = "Location")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro la Ubicacion en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Location.class, responseContainer = "Location")})	
	@PostMapping
	public ResponseEntity<Location> registrar(@Valid @RequestBody Location user) {				
		Location obj = locationService.save(user);	
		return new ResponseEntity<Location>(obj, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para actualizar una ubicacion en el sistema ",
	            notes = "Necesita el id de la ubicacion",
	            response = Location.class,
	            responseContainer = "Location")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro la Ubicacion en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Location.class, responseContainer = "Location")})	
	@PutMapping
	public ResponseEntity<Location> modificar(@Valid @RequestBody Location user) {
		Location obj = locationService.update(user);
		return new ResponseEntity<Location>(obj, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para eliminar Ubicacion",
	            notes = "Necesita id",
	            response = HttpStatus.class,
	            responseContainer = "HttpStatus")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se tiene permiso para realizar esta accion", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = HttpStatus.class, responseContainer = "HttpStatus")})
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> eliminar(@PathVariable("id") Long id) throws Exception {
		locationService.deleteById(id);
		return new ResponseEntity<Object>(HttpStatus.OK);
	}
}
