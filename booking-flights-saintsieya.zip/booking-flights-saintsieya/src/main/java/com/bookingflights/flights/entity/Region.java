package com.bookingflights.flights.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Entity
@Table(name = "region")
@ApiModel(description = "Información o propiedes de Region")
@Data
public class Region {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_region")
	private Long idRegion;
	
	@ApiModelProperty(notes = "Nombre de la Region",required=true)
    @Size(min = 2, max = 500, message = "El nombre debe ser mayor a 2 caracteres y menos a 500")
	@Column(name = "name")
	private String name;



}
