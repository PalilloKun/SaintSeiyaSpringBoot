package com.bookingflights.flights.service;

import com.bookingflights.flights.entity.Airplane;
import com.bookingflights.flights.service.ICRUD.ICRUD;

public interface AirplaneService  extends ICRUD<Airplane>{

}
