package com.bookingflights.flights.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Entity
@Table(name = "location")
@ApiModel(description = "Información o propiedes de Location")
@Data
public class Location {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_location")
	private Long idLocation;
	
	@ApiModelProperty(notes = "Nombre de la Location",required=true)
    @Size(min = 2, max = 500, message = "El nombre debe ser mayor a 2 caracteres y menos a 500")
	@Column(name = "name")
	private String name;
	
	@ApiModelProperty(notes = "ID de la Region",required=true)
	@ManyToOne
    @JoinColumn(name = "id_region", nullable = false)
	private Region region;
	

	
	

}
