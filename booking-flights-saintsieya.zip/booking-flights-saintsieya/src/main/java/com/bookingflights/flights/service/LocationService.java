package com.bookingflights.flights.service;

import com.bookingflights.flights.entity.Location;
import com.bookingflights.flights.service.ICRUD.ICRUD;


public interface LocationService  extends ICRUD<Location>{

}
