package com.bookingflights.flights.DTO;

import java.sql.Date;
import lombok.Data;

@Data
public class FlightDTO {	
	
	private Long idFlight;
	private String flightNumber;
	private LocationDTO locationDepart;
	private Date datetimeDepart;
	private LocationDTO locationArrive;
	private Date datetimeArrive;
	private Long price;
	private boolean freeMeals;
	private boolean refundable;
	
	public FlightDTO() {}
	
	public FlightDTO(Long idFlight){
		this.idFlight = idFlight;
	}
}
