package com.bookingflights.flights.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bookingflights.flights.entity.Booking;
import com.bookingflights.flights.response.ExceptionResponse;
import com.bookingflights.flights.service.BookingService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/bookings")
public class BookingController {

	@Autowired
	private BookingService bookingService;
	
	 @ApiOperation(value = "Obtener la lista de todos las reservas de vuelos existentes en el sistema",
	            notes = "No necesita parametros de entrada",
	            response = List.class,
	            responseContainer = "Booking")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontraron  Reservas de Vuelos en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Booking.class, responseContainer = "List")})
	@GetMapping
	public ResponseEntity<List<Booking>> listar(){
		
		List<Booking> lista = bookingService.findAll();		
		return new ResponseEntity<List<Booking>>(lista, HttpStatus.OK);
	}	
	
	 
	 
	 @ApiOperation(value = "Obtener una reserva de vuelo por su ID ",
	            notes = "Necesita el ID de la reserva",
	            response = Booking.class,
	            responseContainer = "Booking")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro la  Reserva de Vuelo en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Booking.class, responseContainer = "Booking")})	
	@GetMapping("/{id}")
	public ResponseEntity <Booking> finbyid(@PathVariable("id") Long id){
		
		Booking lista = bookingService.findById(id);		
		return new ResponseEntity<Booking>(lista, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para registrar nuevas Reservas de Vuelos en el sistema ",
	            notes = "Necesita fecha de la reserva, id del usuario, id del vuelo, id del tipo de clase, numero de pasajeros, estatus",
	            response = Booking.class,
	            responseContainer = "Booking")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el  Reservas de Vuelos en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Booking.class, responseContainer = "Booking")})	
	@PostMapping
	public ResponseEntity<Booking> registrar(@Valid @RequestBody Booking user) {				
		Booking obj = bookingService.save(user);	
		return new ResponseEntity<Booking>(obj, HttpStatus.OK);
	}
	

	 @ApiOperation(value = "Metodo para actualizar una Reserva de Vuelos en el sistema ",
	            notes = "Necesita  id de la reserava, opcionales: fecha de la reserva, id del usuario, id del vuelo, id del tipo de clase, numero de pasajeros, estatus",
	            response = Booking.class,
	            responseContainer = "Booking")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro  la Reserva de Vuelo en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Booking.class, responseContainer = "Booking")})	
	@PutMapping
	public ResponseEntity<Booking> modificar(@Valid @RequestBody Booking user) {
		Booking obj = bookingService.update(user);
		return new ResponseEntity<Booking>(obj, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para eliminar un Reserva de Vuelo",
	            notes = "Necesita id",
	            response = HttpStatus.class,
	            responseContainer = "HttpStatus")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se tiene permiso para realizar esta accion", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = HttpStatus.class, responseContainer = "HttpStatus")})
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> eliminar(@PathVariable("id") Long id) throws Exception {
		bookingService.deleteById(id);
		return new ResponseEntity<Object>(HttpStatus.OK);
	}
}
