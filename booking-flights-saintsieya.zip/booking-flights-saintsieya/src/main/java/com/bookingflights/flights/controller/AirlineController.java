package com.bookingflights.flights.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bookingflights.flights.entity.Airline;
import com.bookingflights.flights.response.ExceptionResponse;
import com.bookingflights.flights.service.AirlineService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/airlines")
public class AirlineController {

	@Autowired
	private AirlineService airlineService;
	
	 @ApiOperation(value = "Obtener la lista de Aereolineas en el sistema",
	            notes = "No necesita parametros de entrada",
	            response = List.class,
	            responseContainer = "Airline")
	 @ApiParam()
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontraron Aereolineas en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Airline.class, responseContainer = "List")})
	@GetMapping
	public ResponseEntity<List<Airline>> listar(){
		
		List<Airline> lista = airlineService.findAll();		
		return new ResponseEntity<List<Airline>>(lista, HttpStatus.OK);
	}	
	 
	 
	 @ApiOperation(value = "Obtener una Aereolinea del sistema ",
	            notes = "Necesita el ID ",
	            response = Airline.class,
	            responseContainer = "Airline")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro la Aereolinea en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Airline.class, responseContainer = "Airline")})	
	@GetMapping("/{id}")
	public ResponseEntity <Airline> finbyid(@PathVariable("id") Long id){
		
		Airline lista = airlineService.findById(id);		
		return new ResponseEntity<Airline>(lista, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para registrar  una Aereolinea en el sistema",
	            notes = "Necesita nombre, nombre corto y logo",
	            response = Airline.class,
	            responseContainer = "Airline")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro la Capacidad de Avion en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Airline.class, responseContainer = "Airline")})	
	@PostMapping
	public ResponseEntity<Airline> registrar(@Valid @RequestBody Airline user) {		
		Airline obj = airlineService.save(user);	
		return new ResponseEntity<Airline>(obj, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para actualizar una Aereolinea en el sistema",
	            notes = "Necesita id de la Aereolinea, opcional nombre, nombre corto y logo",
	            response = Airline.class,
	            responseContainer = "Airline")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro la Aereolinea en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Airline.class, responseContainer = "Airline")})	
	@PutMapping
	public ResponseEntity<Airline> modificar(@Valid @RequestBody Airline user) {
		Airline obj = airlineService.update(user);
		return new ResponseEntity<Airline>(obj, HttpStatus.OK);
	}
	 
	 
	 @ApiOperation(value = "Metodo para una Aereolinea en el sistema",
	            notes = "Necesita id",
	            response = HttpStatus.class,
	            responseContainer = "HttpStatus")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se tiene permiso para realizar esta accion", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = HttpStatus.class, responseContainer = "HttpStatus")})
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> eliminar(@PathVariable("id") Long id) throws Exception {
		airlineService.deleteById(id);
		return new ResponseEntity<Object>(HttpStatus.OK);
	}

}
