package com.bookingflights.flights.service.imp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookingflights.flights.entity.Booking;

import com.bookingflights.flights.repository.BookingRepository;
import com.bookingflights.flights.service.BookingService;


@Service
public class BookingServiceImp implements BookingService{
	
	@Autowired
	BookingRepository bookingRepository;

	@Override
	public Booking findById(Long id) {
		Optional<Booking>opt = bookingRepository.findById(id);
		return opt.get();
	}

	@Override
	public List<Booking> findAll() {
		
		return bookingRepository.findAll();
	}

	@Override
	public Booking save(Booking e) {
		
		return bookingRepository.save(e);
	}

	@Override
	public Booking update(Booking e) {
		return bookingRepository.save(e);
	}

	@Override
	public void deleteById(Long id) throws Exception {
		bookingRepository.deleteById(id);
		
	}

}
