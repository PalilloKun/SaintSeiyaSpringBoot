package com.bookingflights.flights.service;

import com.bookingflights.flights.entity.Region;
import com.bookingflights.flights.service.ICRUD.ICRUD;

public interface RegionService extends ICRUD<Region>{

}
