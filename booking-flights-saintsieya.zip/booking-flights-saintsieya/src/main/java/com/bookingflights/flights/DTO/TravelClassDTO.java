package com.bookingflights.flights.DTO;

import lombok.Data;

@Data
public class TravelClassDTO {


	private Long id;
	private String name;
}
