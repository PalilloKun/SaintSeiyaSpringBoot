package com.bookingflights.flights.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bookingflights.flights.entity.Genre;


@Repository
public interface GenreRepository  extends JpaRepository<Genre,Long>{

}
