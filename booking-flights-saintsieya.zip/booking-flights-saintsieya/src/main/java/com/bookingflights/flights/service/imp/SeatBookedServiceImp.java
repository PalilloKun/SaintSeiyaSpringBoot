package com.bookingflights.flights.service.imp;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookingflights.flights.entity.SeatBooked;
import com.bookingflights.flights.repository.SeatBookedRepository;
import com.bookingflights.flights.service.SeatBookedService;

@Service
public class SeatBookedServiceImp implements SeatBookedService{
	
	@Autowired
	SeatBookedRepository seatbookedRepository;

	@Override
	public SeatBooked findById(Long id) {
		Optional<SeatBooked>opt = seatbookedRepository.findById(id);
		return opt.get();
	}

	@Override
	public List<SeatBooked> findAll() {
		
		return seatbookedRepository.findAll();
	}

	@Transactional(rollbackOn = {RuntimeException.class})
	@Override
	public SeatBooked save(SeatBooked e) {
		
		return seatbookedRepository.save(e);
	}

	@Transactional(rollbackOn = {RuntimeException.class})
	@Override
	public SeatBooked update(SeatBooked e) {
		return seatbookedRepository.save(e);
	}

	@Transactional(rollbackOn = {RuntimeException.class})
	@Override
	public void deleteById(Long id) throws Exception {
		seatbookedRepository.deleteById(id);
		
	}

}
