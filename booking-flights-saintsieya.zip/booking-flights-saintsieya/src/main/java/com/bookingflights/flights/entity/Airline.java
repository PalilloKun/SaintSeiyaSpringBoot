package com.bookingflights.flights.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Entity
@Table(name = "airline")
@ApiModel(description = "Información o propiedes de Airline")
@Data
public class Airline {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_airline")
	private Long idAirline;
	
	
	@ApiModelProperty(notes = "Nombre del Airline",required=true)
    @Size(min = 2, max = 500, message = "El nombre debe ser mayor a 2 caracteres y menos a 500")
	@Column(name = "name")
	private String name;
	
	
	@ApiModelProperty(notes = "Shortname del Airline",required=true)
    @Size(min = 2, max = 500, message = "El shortname debe ser mayor a 2 caracteres y menos a 10")
	@Column(name = "short_name")
	private String short_name;	
	
	@ApiModelProperty(notes = "Logo del Airline",required=true)
    @Size(min = 10, max = 500, message = "El Logo debe ser mayor a 20 caracteres y menos a 500")
	@Column(name = "logo")
	private String logo;
	
	

}
