package com.bookingflights.flights.service.ICRUD;

import java.util.List;

public interface ICRUD<E> {
	
	  	E findById(Long id);
	    List<E> findAll();
	    E save(E e);
	    E update(E e);
	    void deleteById(Long id) throws Exception;
}
