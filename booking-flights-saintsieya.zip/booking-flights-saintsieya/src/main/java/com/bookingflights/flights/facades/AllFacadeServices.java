package com.bookingflights.flights.facades;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bookingflights.flights.DTO.UserDTO;
import com.bookingflights.flights.entity.User;
import com.bookingflights.flights.mapper.MapStructMapper;
import com.bookingflights.flights.service.UserService;

@Component
public class AllFacadeServices {

	@Autowired
	public UserService userService;
	
	@Autowired
	 private MapStructMapper mapstructMapper;
	
	public List<UserDTO> findAll(){
		List<User> datos = userService.findAll();
		
		System.out.println("totalllll "+String.valueOf( datos.size()));
		
		List<UserDTO> convert = mapstructMapper.listUserDto(datos);
		return convert;
	}
}
