package com.bookingflights.flights.exception;

import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class ExceptionResponse {
	
	
	 	private LocalDateTime timestamp;
	    private String mensaje;
	    private String detalles;

	    public ExceptionResponse(LocalDateTime timestamp, String mensaje, String detalles) {
	        this.timestamp = timestamp;
	        this.mensaje = mensaje;
	        this.detalles = detalles;
	    }
}
