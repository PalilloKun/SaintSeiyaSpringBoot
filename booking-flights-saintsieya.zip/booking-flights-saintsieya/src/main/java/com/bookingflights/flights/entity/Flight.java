package com.bookingflights.flights.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.NamedNativeQueries;
import org.hibernate.annotations.NamedNativeQuery;
import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;



@Entity
@Table(name = "flight")
@ApiModel(description = "Información o propiedes de Flight")
@NamedQueries({
	@NamedQuery(name = "Flight.customBetweenDates",
	        query = "SELECT b FROM Flight b WHERE b.datetime_depart >= :ini AND b.datetime_arrive <= :end"),	
})
@NamedNativeQueries({
	 @NamedNativeQuery(name = "Flight.customComplexQuery",
		     query = ":QUERY ",
		     resultClass = Flight.class)
})
@Data
public class Flight {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_flight")
	private Long idFlight;
	
	@ApiModelProperty(notes = "Identificador de Flight",required=true)
    @Size(min = 2, max = 20, message = "La descripcion debe ser mayor a 2 caracteres y menos a 20")
	@Column(name = "flight_number")
	private String flight_number;
	
	@ApiModelProperty(notes = "ID de la salida de Flight",required=true)
	@ManyToOne  
	@JoinColumn(name="location_depart_id",referencedColumnName="id_location", nullable = false)
	private Location location_depart;
		
	@ApiModelProperty(notes = "Hora de salida de Flight",required=true)
	@NotNull(message="Valor requerido")
	@Column(name = "datetime_depart")
	private Date datetime_depart;
	
	@ApiModelProperty(notes = "ID de la llegada de Flight",required=true)
	@ManyToOne
	@JoinColumn(name="location_arrive_id",referencedColumnName="id_location", nullable = false)
	private Location location_arrive;
	
	@ApiModelProperty(notes = "Hora de llegada de Flight",required=true)
	@NotNull(message="Valor requerido")
	@Column(name = "datetime_arrive")
	private Date datetime_arrive;
	
	@ApiModelProperty(notes = "Precio de Flight",required=true)
	@NotNull(message="Valor requerido")
	@Column(name = "price")
	private Long price;
	
	@ApiModelProperty(notes = "Alimentos gratis de Flight",required=true)
	@NotNull(message="Valor requerido")
	@Column(name = "free_meals")
	private boolean free_meals;
	
	@ApiModelProperty(notes = "Reembolso de Flight",required=true)
	@NotNull(message="Valor requerido")
	@Column(name = "refundable")
	private boolean refundable;

}
