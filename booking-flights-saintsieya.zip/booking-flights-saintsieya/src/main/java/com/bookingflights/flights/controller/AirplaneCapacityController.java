package com.bookingflights.flights.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bookingflights.flights.entity.Airplane;
import com.bookingflights.flights.entity.AirplaneCapacity;
import com.bookingflights.flights.response.ExceptionResponse;
import com.bookingflights.flights.service.AirplaneCapacityService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/airplanescapacities")
public class AirplaneCapacityController {

	@Autowired
	AirplaneCapacityService airplaneCapacityService;
	
	
	 @ApiOperation(value = "Obtener la lista de capacidades de aviones en el sistema",
	            notes = "No necesita parametros de entrada",
	            response = List.class,
	            responseContainer = "Airplane")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontraron Capacidades de Avion en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Airplane.class, responseContainer = "List")})
	@GetMapping
	public ResponseEntity<List<AirplaneCapacity>> listar(){
		
		List<AirplaneCapacity> lista = airplaneCapacityService.findAll();		
		return new ResponseEntity<List<AirplaneCapacity>>(lista, HttpStatus.OK);
	}	
	
	 
	 @ApiOperation(value = "Obtener la lista de capacidades de un avion ",
	            notes = "Necesita el ID ",
	            response = AirplaneCapacity.class,
	            responseContainer = "AirplaneCapacity")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro la capacidad de avion en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = AirplaneCapacity.class, responseContainer = "AirplaneCapacity")})	
	@GetMapping("/{id}")
	public ResponseEntity<List<AirplaneCapacity>> finbyid(@PathVariable("id") Long id){
		
		 List<AirplaneCapacity> lista = airplaneCapacityService.findByIdAirplanecapacity(id);		
		 return new ResponseEntity<List<AirplaneCapacity>>(lista, HttpStatus.OK);
	}
	 
	 
	 @ApiOperation(value = "Metodo para registrar  una nueva  capacidad de avion",
	            notes = "Necesita id de la aereolinea, id de tipo de clase y la cantidad de pasajeros",
	            response = AirplaneCapacity.class,
	            responseContainer = "AirplaneCapacity")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro la Capacidad de Avion en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = AirplaneCapacity.class, responseContainer = "AirplaneCapacity")})	
	@PostMapping
	public ResponseEntity<AirplaneCapacity> registrar(@Valid @RequestBody AirplaneCapacity user) {				
		AirplaneCapacity obj = airplaneCapacityService.save(user);	
		return new ResponseEntity<AirplaneCapacity>(obj, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para actualizar  una nueva  capacidad de avion",
	            notes = "Necesita id de la capacidad del avion, opcional :   id de la aereolinea, id de tipo de clase y la cantidad de pasajeros",
	            response = AirplaneCapacity.class,
	            responseContainer = "AirplaneCapacity")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro la Capacidad de Avion en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = AirplaneCapacity.class, responseContainer = "AirplaneCapacity")})	
	@PutMapping
	public ResponseEntity<AirplaneCapacity> modificar(@Valid @RequestBody AirplaneCapacity user) {
		AirplaneCapacity obj = airplaneCapacityService.update(user);
		return new ResponseEntity<AirplaneCapacity>(obj, HttpStatus.OK);
	}
	
	 
	 @ApiOperation(value = "Metodo para eliminar una capacidad en el sistema",
	            notes = "Necesita id",
	            response = HttpStatus.class,
	            responseContainer = "HttpStatus")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se tiene permiso para realizar esta accion", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = HttpStatus.class, responseContainer = "HttpStatus")})
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> eliminar(@PathVariable("id") Long id) throws Exception {
		airplaneCapacityService.deleteById(id);
		return new ResponseEntity<Object>(HttpStatus.OK);
	}

}
