package com.bookingflights.flights.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Entity
@Table(name = "travel_class")
@ApiModel(description = "Información o propiedes del Travel Class")
@Data
public class TravelClass {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_travel_class")
	private Long idTravelClass;
	
	@ApiModelProperty(notes = "Clase del vuelo",required=true)
    @Size(min = 2, max = 500, message = "El nombre debe ser mayor a 2 caracteres y menos a 500")
	@Column(name = "name")
	private String name;

	
	
}
