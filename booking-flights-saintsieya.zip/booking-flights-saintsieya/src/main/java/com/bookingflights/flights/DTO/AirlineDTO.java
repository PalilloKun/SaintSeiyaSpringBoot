package com.bookingflights.flights.DTO;

import lombok.Data;

@Data
public class AirlineDTO {

	
	
	private Long id;
	private String name;
	private String short_name;		
	private String logo;
}
