package com.bookingflights.flights.service.imp;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookingflights.flights.entity.Airplane;

import com.bookingflights.flights.repository.AirplaneRepository;
import com.bookingflights.flights.service.AirplaneService;

@Service
public class AirplaneServiceImp implements AirplaneService{
	
	@Autowired
	AirplaneRepository airplaneRepository;

	@Override
	public Airplane findById(Long id) {
		Optional<Airplane>opt = airplaneRepository.findById(id);
		return opt.get();
	}

	@Override
	public List<Airplane> findAll() {
		
		return airplaneRepository.findAll();
	}

	@Transactional
	@Override
	public Airplane save(Airplane e) {
		// TODO Auto-generated method stub
		return airplaneRepository.save(e);
	}
	@Transactional
	@Override
	public Airplane update(Airplane e) {
		
		return airplaneRepository.save(e);
	}
	@Transactional
	@Override
	public void deleteById(Long id) throws Exception {
		airplaneRepository.deleteById(id);
		
	}

}
