package com.bookingflights.flights.DTO;


import lombok.Data;

@Data
public class LocationDTO {

	private Long id;
	private String name;
	private RegionDTO region;
	
	public LocationDTO() {}
	
	public LocationDTO(Long id) {
		this.id = id;
	}
}
