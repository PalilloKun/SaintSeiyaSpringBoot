package com.bookingflights.flights.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bookingflights.flights.DTO.FlightDTO;
import com.bookingflights.flights.entity.Flight;


@Repository
public interface FlightRepository  extends JpaRepository<Flight,Long>{

	
	List<Flight> customBetweenDates(Date ini, Date end);
	
	List<FlightDTO> customComplexQuery(String QUERY);
}
