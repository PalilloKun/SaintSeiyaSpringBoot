package com.bookingflights.flights.DTO;
import lombok.Data;


@Data
public class AirplaneDTO {

	private Long id;
	private AirlineDTO airline;
}
