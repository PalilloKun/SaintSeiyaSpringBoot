package com.bookingflights.flights.service.imp;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookingflights.flights.entity.Airline;
import com.bookingflights.flights.repository.AirlineRepository;
import com.bookingflights.flights.service.AirlineService;

@Service
public class AirlineServiceImp implements AirlineService{
	
	@Autowired
	AirlineRepository airlineRepository;

	@Override
	public Airline findById(Long id) {
		Optional<Airline>opt = airlineRepository.findById(id);
		return opt.get();
	}

	@Override
	public List<Airline> findAll() {
		
		return airlineRepository.findAll();
	}

	@Transactional
	@Override
	public Airline save(Airline e) {
		// TODO Auto-generated method stub
		return airlineRepository.save(e);
	}

	@Transactional
	@Override
	public Airline update(Airline e) {
		// TODO Auto-generated method stub
		return airlineRepository.save(e);
	}

	@Transactional
	@Override
	public void deleteById(Long id) throws Exception {
		airlineRepository.deleteById(id);
		
	}

}
