package com.bookingflights.flights.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonBackReference;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "booking")
@ApiModel(description = "Información o propiedes de Booking")
@Setter
@Getter
public class Booking {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_booking")
	private Long idBooking;
	
	
	@ApiModelProperty(notes = "Hora en que se realizo en Booking",required=true)
	@NotNull(message="Valor requerido")
	@Column(name = "booking_schelude")
	private Date booking_schelude;
	
	
	@ApiModelProperty(notes = "ID del Flight",required=true)
	@ManyToOne
    @JoinColumn(name = "id_flight", nullable = false)
	private Flight flight;
	
	@ApiModelProperty(notes = "ID del User",required=true)
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonBackReference
    @JoinColumn(name = "id_user", nullable = false)
	private User user;
	
	@ApiModelProperty(notes = "ID del Travel Class",required=true)
	@ManyToOne
    @JoinColumn(name = "id_travel_class", nullable = false)
	private TravelClass travel_class;
	
	@ApiModelProperty(notes = "Numero de viajeros",required=true)
    @Min(value =1,message="Minimo de viajeros 1")
	@Column(name = "no_travelers")
	private Integer no_travelers;
	
	@ApiModelProperty(notes = "Estatus del Booking (booleano)",required=true)   
	@NotNull(message="Valor requerido")
	@Column(name = "status")
	private boolean status;

}
