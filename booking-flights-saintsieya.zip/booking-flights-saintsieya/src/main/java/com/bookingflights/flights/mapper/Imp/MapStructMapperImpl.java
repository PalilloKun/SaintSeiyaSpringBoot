package com.bookingflights.flights.mapper.Imp;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bookingflights.flights.DTO.AirlineDTO;
import com.bookingflights.flights.DTO.AirplaneCapacityDTO;
import com.bookingflights.flights.DTO.AirplaneDTO;
import com.bookingflights.flights.DTO.BookingDTO;
import com.bookingflights.flights.DTO.FlightDTO;
import com.bookingflights.flights.DTO.GenreDTO;
import com.bookingflights.flights.DTO.LocationDTO;
import com.bookingflights.flights.DTO.RegionDTO;
import com.bookingflights.flights.DTO.SeatBookedDTO;
import com.bookingflights.flights.DTO.TravelClassDTO;
import com.bookingflights.flights.DTO.UserDTO;
import com.bookingflights.flights.entity.Airline;
import com.bookingflights.flights.entity.Airplane;
import com.bookingflights.flights.entity.AirplaneCapacity;
import com.bookingflights.flights.entity.Booking;
import com.bookingflights.flights.entity.Flight;
import com.bookingflights.flights.entity.Genre;
import com.bookingflights.flights.entity.Location;
import com.bookingflights.flights.entity.Region;
import com.bookingflights.flights.entity.SeatBooked;
import com.bookingflights.flights.entity.TravelClass;
import com.bookingflights.flights.entity.User;
import com.bookingflights.flights.mapper.MapStructMapper;

@Component
public class MapStructMapperImpl implements MapStructMapper {


	private ModelMapper mapper  = new ModelMapper();;
	
	@Override
	public UserDTO userToUserDTO(User user) {
		
		UserDTO dto = mapper.map(user, UserDTO.class);
	/*	UserDTO dto = new UserDTO();
		dto.setAddress(user.getAddress());
		dto.setEmail(user.getEmail());
		dto.setGenreDTO(new GenreDTO(user.getGenre().getIdGenre(),user.getGenre().getDescription(),user.getGenre().isStatus()));
		dto.setLast_name(user.getName());
		dto.setMiddle_name(user.getMiddle_name());
		dto.setName(user.getName());
		dto.setPassword(user.getPassword());
		dto.setPhone_number(user.getPhone_number());
		dto.setSurname(user.getSurname());
		
		if(user.getIdUser()!=null) {
			dto.setId(user.getIdUser());
		}
	
		*/
		return dto;
	}

	@Override
	public User userDtoToUser(UserDTO userDTO) {
		
		User dto = mapper.map(userDTO, User.class);
		/*
		User dto = new User();
		dto.setAddress(userDTO.getAddress());
		dto.setEmail(userDTO.getEmail());
		dto.setGenre(new Genre(userDTO.getGenreDTO().getId(),userDTO.getGenreDTO().getDescription(),userDTO.getGenreDTO().isStatus()));
		dto.setLast_name(userDTO.getName());
		dto.setMiddle_name(userDTO.getMiddle_name());
		dto.setName(userDTO.getName());
		dto.setPassword(userDTO.getPassword());
		dto.setPhone_number(userDTO.getPhone_number());
		dto.setSurname(userDTO.getSurname());
		
		if(userDTO.getId()!=null) {
			dto.setIdUser(userDTO.getId());
		}
	*/
		
		return dto;
	}

	@Override
	public TravelClassDTO travelClassToTravelClassDTO(TravelClass travelClass) {
		
		TravelClassDTO dto = mapper.map(travelClass, TravelClassDTO.class);
		/*TravelClassDTO dto = new TravelClassDTO();
		dto.setId(travelClass.getIdTravelClass());
		dto.setName(travelClass.getName());
		*/
		return dto;
	}

	@Override
	public TravelClass travelClassDTOToTravelClass(TravelClassDTO travelClassDTO) {
		
		TravelClass dto = mapper.map(travelClassDTO, TravelClass.class);
		
		return dto;
	}

	@Override
	public SeatBookedDTO seatBookedToSeatBookedDTO(SeatBooked seatBooked) {
		SeatBookedDTO dto = mapper.map(seatBooked, SeatBookedDTO.class);
		return dto;
	}

	@Override
	public SeatBooked seatBookedDTOToSeatBooked(SeatBookedDTO seatBooked) {
		SeatBooked dto = mapper.map(seatBooked, SeatBooked.class);
		return dto;
	}

	@Override
	public RegionDTO regionToRegionDTO(Region region) {
		RegionDTO dto = mapper.map(region, RegionDTO.class);
		return dto;
	}

	@Override
	public Region regionDTOToRegion(RegionDTO regionDTO) {
		Region dto = mapper.map(regionDTO, Region.class);
		return dto;
	}

	@Override
	public LocationDTO locationToLocationDTO(Location location) {
		LocationDTO dto = mapper.map(location, LocationDTO.class);
		return dto;
	}

	@Override
	public Location locationDTOToLocation(LocationDTO locationDTO) {
		Location dto = mapper.map(locationDTO, Location.class);
		return dto;
	}

	@Override
	public GenreDTO genreToSeatGenreDTO(Genre genre) {
		GenreDTO dto = mapper.map(genre, GenreDTO.class);
		return dto;
	}

	@Override
	public Genre genreDTOToSeatGenre(GenreDTO genreDTO) {
		Genre dto = mapper.map(genreDTO, Genre.class);
		return dto;
	}

	@Override
	public FlightDTO flightToSeatFlightDTO(Flight flight) {
		FlightDTO dto = mapper.map(flight, FlightDTO.class);
		return dto;
	}

	@Override
	public Flight FlightDTOToSeatFlight(FlightDTO flightDTO) {
		Flight dto = mapper.map(flightDTO, Flight.class);
		return dto;
	}

	@Override
	public BookingDTO bookingToSeatBookingDTO(Booking booking) {
		BookingDTO dto = mapper.map(booking, BookingDTO.class);
		return dto;
	}

	@Override
	public Booking bookingDTOToBooking(BookingDTO bookingDTO) {
		Booking dto = mapper.map(bookingDTO, Booking.class);
		return dto;
	}

	@Override
	public AirplaneCapacityDTO airplaneCapacityToSeatAirplaneCapacityDTO(AirplaneCapacity airplaneCapacity) {
		AirplaneCapacityDTO dto = mapper.map(airplaneCapacity, AirplaneCapacityDTO.class);
		return dto;
	}

	@Override
	public AirplaneCapacity airplaneCapacityDTOToAirplaneCapacity(AirplaneCapacityDTO airplaneCapacityDTO) {
		AirplaneCapacity dto = mapper.map(airplaneCapacityDTO, AirplaneCapacity.class);
		return dto;
	}

	@Override
	public AirplaneDTO airplaneToSeatAirplaneDTO(Airplane airplane) {
		AirplaneDTO dto = mapper.map(airplane, AirplaneDTO.class);
		return dto;
	}

	@Override
	public Airplane airplaneDTOToAirplane(AirplaneDTO airplaneDTO) {
		Airplane dto = mapper.map(airplaneDTO, Airplane.class);
		return dto;
	}

	@Override
	public AirlineDTO AirlineToSeatAirlineDTO(Airline airline) {
		AirlineDTO dto = mapper.map(airline, AirlineDTO.class);
		return dto;
	}

	@Override
	public Airline airlineDTOToAirline(AirlineDTO airlineDTO) {
		Airline dto = mapper.map(airlineDTO, Airline.class);
		return dto;
	}

	@Override
	public List<UserDTO> listUserDto(List<User> users) {
		List<UserDTO> dtos = new ArrayList<>();
	/*	for(User dto : users) {
			
			System.out.println("valor es "+dto.getAddress());
			UserDTO d =  mapper.map(dto, UserDTO.class);
		}*/
		 dtos = users.stream()
				  .map(user -> this.userToUserDTO(user))
				  .collect(Collectors.toList());
		/* dtos = users.stream()
				  .map(user -> mapper.map(user, UserDTO.class))
				  .collect(Collectors.toList());*/
		return dtos;
	}
	
	public<S, T> List<T> mapList(List<S> source, Class<T> targetClass) {
	    return source
	      .stream()
	      .map(element -> mapper.map(element, targetClass))
	      .collect(Collectors.toList());
	}

}
