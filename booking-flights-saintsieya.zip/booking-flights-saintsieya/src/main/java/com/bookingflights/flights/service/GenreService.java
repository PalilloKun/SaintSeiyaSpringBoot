package com.bookingflights.flights.service;

import com.bookingflights.flights.entity.Genre;
import com.bookingflights.flights.service.ICRUD.ICRUD;

public interface GenreService extends  ICRUD<Genre>{

}
