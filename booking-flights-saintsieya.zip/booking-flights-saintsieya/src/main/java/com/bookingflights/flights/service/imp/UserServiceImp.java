package com.bookingflights.flights.service.imp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
//import org.springframework.security.core.userdetails.User;
import com.bookingflights.flights.entity.User;
import com.bookingflights.flights.repository.UserRepository;
import com.bookingflights.flights.service.UserService;
import java.util.Optional;
import javax.transaction.Transactional;

@Service
public class UserServiceImp implements UserDetailsService, UserService{
	
	
	@Autowired
	private UserRepository userRepository;
	
	@Override
	public User findById(Long id) {
		Optional<User> op = userRepository.findById(id);
		return op.get();
	}

	@Override
	public List<User> findAll() {
		return userRepository.findAll();
	}

	@Transactional
	@Override
	public User save(User e) {
		return userRepository.save(e);
	}
	@Transactional
	@Override
	public User update(User e) {
		return userRepository.save(e);
	}
	@Transactional
	@Override
	public void deleteById(Long id) throws Exception {
		 userRepository.deleteById(id);
	}
	/////////////////////////////

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		
		//User usuario =  userRepository.findOneByName(username);
		User usuario =  userRepository.findOneByEmail(email);
		if(usuario == null) {
			throw new UsernameNotFoundException(String.format("Usuario no existe", email));
		}
		List<GrantedAuthority> roles = new ArrayList<>();
		System.out.println("ROLE "+usuario.getRols().size());
		usuario.getRols().forEach(rol -> {
			System.out.println("ROLE "+rol.getName());
			roles.add(new SimpleGrantedAuthority(rol.getName()));
		});
		UserDetails ud = new  org.springframework.security.core.userdetails.User(usuario.getEmail(), usuario.getPassword(), roles);
		return ud;
		
	}

}
