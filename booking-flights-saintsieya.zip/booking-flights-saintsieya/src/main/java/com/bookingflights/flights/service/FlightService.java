package com.bookingflights.flights.service;

import java.util.List;


import com.bookingflights.flights.DTO.FlightDTO;
import com.bookingflights.flights.entity.Flight;
import com.bookingflights.flights.service.ICRUD.ICRUD;
import java.sql.Date;
public interface FlightService   extends ICRUD<Flight>{
	
	List<Flight> customBetweenDates(Date ini,  Date end);
	
	List<FlightDTO> customComplexQuery(String QUERY);

}
