package com.bookingflights.flights.service;

import com.bookingflights.flights.entity.Airline;
import com.bookingflights.flights.service.ICRUD.ICRUD;

public interface AirlineService extends  ICRUD<Airline>{

}
