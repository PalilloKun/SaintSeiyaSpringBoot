package com.bookingflights.flights.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bookingflights.flights.entity.Genre;
import com.bookingflights.flights.response.ExceptionResponse;
import com.bookingflights.flights.service.GenreService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/genres")
public class GenreController {

	
	@Autowired
	private GenreService genreService;
	

	 @ApiOperation(value = "Obtener la lista de todos los generos",
	            notes = "No necesita parametros de entrada",
	            response = List.class,
	            responseContainer = "Genre")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontraron  Generos en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Genre.class, responseContainer = "List")})
	@GetMapping
	public ResponseEntity<List<Genre>> listar(){
		
		List<Genre> lista = genreService.findAll();		
		return new ResponseEntity<List<Genre>>(lista, HttpStatus.OK);
	}	
	
	 @ApiOperation(value = "Obtener el genero por su ID ",
	            notes = "Necesita el ID del genero",
	            response = Genre.class,
	            responseContainer = "Location")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el Genero en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Genre.class, responseContainer = "Genre")})	
	@GetMapping("/{id}")
	public ResponseEntity <Genre> finbyid(@PathVariable("id") Long id){
		
		Genre lista = genreService.findById(id);		
		return new ResponseEntity<Genre>(lista, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para registrar nuevos Generos en el sistema ",
	            notes = "Necesita la descripcion y un estatus",
	            response = Genre.class,
	            responseContainer = "Genre")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el Genero en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Genre.class, responseContainer = "Genre")})	
	@PostMapping
	public ResponseEntity<Genre> registrar(@Valid @RequestBody Genre user) {		
		Genre obj = genreService.save(user);	
		return new ResponseEntity<Genre>(obj, HttpStatus.OK);
	}
	
	 
	 @ApiOperation(value = "Metodo para actualizar un Genero el sistema ",
	            notes = "Necesita el id del genero",
	            response = Genre.class,
	            responseContainer = "Genre")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el Genero en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Genre.class, responseContainer = "Genre")})	
	@PutMapping
	public ResponseEntity<Genre> modificar(@Valid @RequestBody Genre user) {
		Genre obj = genreService.update(user);
		return new ResponseEntity<Genre>(obj, HttpStatus.OK);
	}
	
	 
	 @ApiOperation(value = "Metodo para eliminar un Genero",
	            notes = "Necesita id",
	            response = HttpStatus.class,
	            responseContainer = "HttpStatus")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se tiene permiso para realizar esta accion", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = HttpStatus.class, responseContainer = "HttpStatus")})
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> eliminar(@PathVariable("id") Long id) throws Exception {
		genreService.deleteById(id);
		return new ResponseEntity<Object>(HttpStatus.OK);
	}
}
