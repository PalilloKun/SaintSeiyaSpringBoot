package com.bookingflights.flights.DTO;

import lombok.Data;

@Data
public class AirplaneCapacityDTO {
	private Long id;	
	private Integer capacity;	
	private AirplaneDTO airplaneDTO;	
	private TravelClassDTO traveClassDTO;
}
