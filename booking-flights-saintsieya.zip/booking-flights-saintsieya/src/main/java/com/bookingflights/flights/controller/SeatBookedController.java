package com.bookingflights.flights.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bookingflights.flights.entity.SeatBooked;
import com.bookingflights.flights.response.ExceptionResponse;
import com.bookingflights.flights.service.SeatBookedService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/seatsbooked")
public class SeatBookedController {

	@Autowired
	private SeatBookedService seatbookedService;
	
	 @ApiOperation(value = "Obtener la lista de los asientos reservados por el id del vuelo y el id de Tipo de clase",
	            notes = "No necesita parametros de entrada",
	            response = List.class,
	            responseContainer = "SeatBooked")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontraron  Tipo de Servicio en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = SeatBooked.class, responseContainer = "List")})
	@GetMapping
	public ResponseEntity<List<SeatBooked>> listar(){
		
		List<SeatBooked> lista = seatbookedService.findAll();		
		return new ResponseEntity<List<SeatBooked>>(lista, HttpStatus.OK);
	}	
	
	 
	 @ApiOperation(value = "Obtener la informacion los asientos reservador por el ID ",
	            notes = "Necesita el ID del usuario",
	            response = SeatBooked.class,
	            responseContainer = "SeatBooked")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el Tipo de Clase en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = SeatBooked.class, responseContainer = "SeatBooked")})	
	@GetMapping("/{id}")
	public ResponseEntity <SeatBooked> finbyid(@PathVariable("id") Long id){
		
		SeatBooked lista = seatbookedService.findById(id);		
		return new ResponseEntity<SeatBooked>(lista, HttpStatus.OK);
	}
	

	 @ApiOperation(value = "Metodo para registrar nuevos asientos reservados ",
	            notes = "Necesita el id del vuelo, id tipo de clase y numero de asientos reservados",
	            response = SeatBooked.class,
	            responseContainer = "TravelClass")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el Tipo de Clase en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = SeatBooked.class, responseContainer = "SeatBooked")})	
	@PostMapping
	public ResponseEntity<SeatBooked> registrar(@Valid @RequestBody SeatBooked user) {				
		SeatBooked obj = seatbookedService.save(user);	
		return new ResponseEntity<SeatBooked>(obj, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para actualizar asientos reservados en el sistema",
	            notes = "Necesita el id ",
	            response = SeatBooked.class,
	            responseContainer = "TravelClass")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el Tipo de Clase en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = SeatBooked.class, responseContainer = "SeatBooked")})	
	@PutMapping
	public ResponseEntity<SeatBooked> modificar(@Valid @RequestBody SeatBooked user) {
		SeatBooked obj = seatbookedService.update(user);
		return new ResponseEntity<SeatBooked>(obj, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para eliminar asiento reservado ",
	            notes = "Necesita id",
	            response = HttpStatus.class,
	            responseContainer = "HttpStatus")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se tiene permiso para realizar esta accion", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = HttpStatus.class, responseContainer = "HttpStatus")})
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> eliminar(@PathVariable("id") Long id) throws Exception {
		seatbookedService.deleteById(id);
		return new ResponseEntity<Object>(HttpStatus.OK);
	}
}
