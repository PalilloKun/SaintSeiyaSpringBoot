package com.bookingflights.flights.service;

import com.bookingflights.flights.entity.Booking;
import com.bookingflights.flights.service.ICRUD.ICRUD;

public interface BookingService extends ICRUD<Booking>{

}
