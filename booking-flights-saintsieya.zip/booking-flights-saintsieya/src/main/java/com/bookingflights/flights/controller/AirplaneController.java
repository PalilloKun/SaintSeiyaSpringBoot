package com.bookingflights.flights.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bookingflights.flights.entity.Airplane;
import com.bookingflights.flights.response.ExceptionResponse;
import com.bookingflights.flights.service.AirplaneService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/airplanes")
public class AirplaneController {
	
	@Autowired
	AirplaneService airplaneService;
	
	
	 @ApiOperation(value = "Obtener la lista de todos los Aviones existentes en el sistema",
	            notes = "No necesita parametros de entrada",
	            response = List.class,
	            responseContainer = "Airplane")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontraron Aviones en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Airplane.class, responseContainer = "List")})
	@GetMapping
	public ResponseEntity<List<Airplane>> listar(){
		
		List<Airplane> lista = airplaneService.findAll();		
		return new ResponseEntity<List<Airplane>>(lista, HttpStatus.OK);
	}	
	
	 
	 @ApiOperation(value = "Obtener un avion existente en el sistema ",
	            notes = "Necesita el ID del avion",
	            response = Airplane.class,
	            responseContainer = "Airplane")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el Avion en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Airplane.class, responseContainer = "Airplane")})	
	@GetMapping("/{id}")
	public ResponseEntity <Airplane> finbyid(@PathVariable("id") Long id){
		
		Airplane lista = airplaneService.findById(id);		
		return new ResponseEntity<Airplane>(lista, HttpStatus.OK);
	}
	

	 @ApiOperation(value = "Metodo para registrar un nuevo avion  el sistema ",
	            notes = "Necesita id de la aereolinea",
	            response = Airplane.class,
	            responseContainer = "Airplane")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro  el Avion en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Airplane.class, responseContainer = "Booking")})	
	@PostMapping
	public ResponseEntity<Airplane> registrar(@Valid @RequestBody Airplane user) {				
		Airplane obj = airplaneService.save(user);	
		return new ResponseEntity<Airplane>(obj, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para actualizar un  avion  el sistema ",
	            notes = "Necesita id del avion, opcional: id de la aereolinea",
	            response = Airplane.class,
	            responseContainer = "Airplane")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro  el Avion en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Airplane.class, responseContainer = "Booking")})	
	@PutMapping
	public ResponseEntity<Airplane> modificar(@Valid @RequestBody Airplane user) {
		Airplane obj = airplaneService.update(user);
		return new ResponseEntity<Airplane>(obj, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para eliminar un avion del sistema",
	            notes = "Necesita id",
	            response = HttpStatus.class,
	            responseContainer = "HttpStatus")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se tiene permiso para realizar esta accion", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = HttpStatus.class, responseContainer = "HttpStatus")})
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> eliminar(@PathVariable("id") Long id) throws Exception {
		airplaneService.deleteById(id);
		return new ResponseEntity<Object>(HttpStatus.OK);
	}


}
