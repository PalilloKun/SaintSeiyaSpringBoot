package com.bookingflights.flights.service;

import com.bookingflights.flights.entity.SeatBooked;
import com.bookingflights.flights.service.ICRUD.ICRUD;

public interface SeatBookedService extends ICRUD<SeatBooked>{

}
