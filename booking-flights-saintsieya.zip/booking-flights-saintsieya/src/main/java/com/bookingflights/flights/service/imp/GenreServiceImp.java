package com.bookingflights.flights.service.imp;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookingflights.flights.entity.Genre;
import com.bookingflights.flights.repository.GenreRepository;
import com.bookingflights.flights.service.GenreService;


@Service
public class GenreServiceImp implements GenreService{

	@Autowired
	private GenreRepository genreRepository;
	
	@Override
	public Genre findById(Long id) {
		Optional<Genre>opt = genreRepository.findById(id);
		return  opt.get();
	}

	@Override
	public List<Genre> findAll() {
		
		return genreRepository.findAll();
	}
	
	@Transactional
	@Override
	public Genre save(Genre e) {
	
		return genreRepository.save(e);
	}

	@Transactional
	@Override
	public Genre update(Genre e) {
		
		return genreRepository.save(e);
	}
	
	@Transactional
	@Override
	public void deleteById(Long id) throws Exception {
		genreRepository.deleteById(id);		
	}

}
