package com.bookingflights.flights.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Entity
@Table(name = "genre")
@ApiModel(description = "Información o propiedes de Genre")
@Data
public class Genre {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_genre")
	private Long idGenre;
	
	
	@ApiModelProperty(notes = "Descripcion del Genre",required=true)
    @Size(min = 2, max = 500, message = "La descripcion debe ser mayor a 2 caracteres y menos a 500")
	@Column(name = "description")
	private String description;
	
	@ApiModelProperty(notes = "Estatus del Genre (booleano)",required=true)   
	@NotNull(message="Valor requerido")
	@Column(name = "status")
	private boolean status;

	public Genre() {}
	
	public Genre(Long idGenre,
			@Size(min = 2, max = 500, message = "La descripcion debe ser mayor a 2 caracteres y menos a 500") String description,
			@NotNull(message = "Valor requerido") boolean status) {
		;
		this.idGenre = idGenre;
		this.description = description;
		this.status = status;
	}
	

	
}
