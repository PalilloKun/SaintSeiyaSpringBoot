package com.bookingflights.flights.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bookingflights.flights.entity.TravelClass;
import com.bookingflights.flights.response.ExceptionResponse;
import com.bookingflights.flights.service.TravelClassService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/travelclasses")
public class TravelClassController {
	
	@Autowired
	private TravelClassService travelclassService;
	
	 @ApiOperation(value = "Obtener la lista de Tipo de Servicio disponibles",
	            notes = "No necesita parametros de entrada",
	            response = List.class,
	            responseContainer = "TravelClass")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontraron  Tipo de Servicio en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = TravelClass.class, responseContainer = "List")})
	@GetMapping
	public ResponseEntity<List<TravelClass>> listar(){
		
		List<TravelClass> lista = travelclassService.findAll();		
		return new ResponseEntity<List<TravelClass>>(lista, HttpStatus.OK);
	}	
	
	 
	 @ApiOperation(value = "Obtener la informacion de un Tipo de Clase por su ID ",
	            notes = "Necesita el ID del usuario",
	            response = TravelClass.class,
	            responseContainer = "TravelClass")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el Tipo de Clase en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = TravelClass.class, responseContainer = "TravelClass")})	
	@GetMapping("/{id}")
	public ResponseEntity <TravelClass> finbyid(@PathVariable("id") Long id){
		
		TravelClass lista = travelclassService.findById(id);		
		return new ResponseEntity<TravelClass>(lista, HttpStatus.OK);
	}
	
	 
	 @ApiOperation(value = "Metodo para registrar un nuevo Tipo de Clase ",
	            notes = "Necesita el name",
	            response = TravelClass.class,
	            responseContainer = "TravelClass")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el Tipo de Clase en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = TravelClass.class, responseContainer = "TravelClass")})	
	@PostMapping
	public ResponseEntity<TravelClass> registrar(@Valid @RequestBody TravelClass user) {		
		TravelClass obj = travelclassService.save(user);	
		return new ResponseEntity<TravelClass>(obj, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para actualizar un Tipo de Clase existente",
	            notes = "Necesita el id",
	            response = TravelClass.class,
	            responseContainer = "TravelClass")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el Tipo de Clase en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = TravelClass.class, responseContainer = "TravelClass")})	
	@PutMapping
	public ResponseEntity<TravelClass> modificar(@Valid @RequestBody TravelClass user) {
		TravelClass obj = travelclassService.update(user);
		return new ResponseEntity<TravelClass>(obj, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para eliminar un Tipo de Clase del sistema ",
	            notes = "Necesita id",
	            response = HttpStatus.class,
	            responseContainer = "HttpStatus")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se tiene permiso para realizar esta accion", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = HttpStatus.class, responseContainer = "HttpStatus")})
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> eliminar(@PathVariable("id") Long id) throws Exception {
		travelclassService.deleteById(id);
		return new ResponseEntity<Object>(HttpStatus.OK);
	}

}
