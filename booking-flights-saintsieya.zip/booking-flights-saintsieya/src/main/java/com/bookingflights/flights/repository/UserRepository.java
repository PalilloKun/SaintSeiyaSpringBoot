package com.bookingflights.flights.repository;



import com.bookingflights.flights.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User,Long>{
	
	
	//ADD OTHER UNIMPLEMENTED METHODS HERE
	
	//select * from usuario where username = ?
	User findOneByName(String username);
	
	User findOneByEmail(String email);
	

}
