package com.bookingflights.flights.service.imp;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookingflights.flights.entity.Role;
import com.bookingflights.flights.repository.RoleRespository;
import com.bookingflights.flights.service.RoleService;

@Service
public class RoleServiceImp  implements RoleService{
	
	@Autowired
	private RoleRespository roleRepository;

	@Override
	public Role findById(Long id) {
		
		
		Optional<Role> op = roleRepository.findById(id);
		return op.get();
	}

	@Override
	public List<Role> findAll() {
		return roleRepository.findAll();
	}

	@Override
	public Role save(Role e) {
		return roleRepository.save(e);
	}
	
	@Transactional
	@Override
	public Role update(Role e) {
		return roleRepository.save(e);
	}

	@Transactional
	@Override
	public void deleteById(Long id) throws Exception {
		roleRepository.deleteById(id);
		
	}

}
