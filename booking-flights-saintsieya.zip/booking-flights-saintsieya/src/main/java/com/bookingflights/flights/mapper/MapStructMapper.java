package com.bookingflights.flights.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.bookingflights.flights.DTO.*;
import com.bookingflights.flights.entity.*;


@Mapper(
	    componentModel = "spring"
)
public interface MapStructMapper {

	
	@Mapping(source = "user.genre", target = "genreDTO")
	UserDTO userToUserDTO(User user);
	@Mapping(source = "userDTO.genreDTO", target = "genre")	
	User userDtoToUser(UserDTO userDTO);
	List<UserDTO> listUserDto (List<User> users); 
	
	
	TravelClassDTO travelClassToTravelClassDTO(TravelClass travelClass);
	TravelClass travelClassDTOToTravelClass(TravelClassDTO travelClassDTO);
	
	SeatBookedDTO seatBookedToSeatBookedDTO(SeatBooked seatBooked);
	SeatBooked seatBookedDTOToSeatBooked(SeatBookedDTO seatBooked);
	
	RegionDTO regionToRegionDTO(Region region);
	Region regionDTOToRegion(RegionDTO regionDTO);
	
	LocationDTO locationToLocationDTO(Location location);
	Location locationDTOToLocation(LocationDTO locationDTO);
	
	GenreDTO genreToSeatGenreDTO(Genre genre);
	Genre genreDTOToSeatGenre(GenreDTO genreDTO);
	
	FlightDTO flightToSeatFlightDTO(Flight flight);
	Flight FlightDTOToSeatFlight(FlightDTO flightDTO);
	
	
	BookingDTO bookingToSeatBookingDTO(Booking booking);
	Booking bookingDTOToBooking(BookingDTO bookingDTO);
	
	
	AirplaneCapacityDTO airplaneCapacityToSeatAirplaneCapacityDTO(AirplaneCapacity airplaneCapacity);
	AirplaneCapacity airplaneCapacityDTOToAirplaneCapacity(AirplaneCapacityDTO airplaneCapacityDTO);
	
	
	AirplaneDTO airplaneToSeatAirplaneDTO(Airplane airplane);
	Airplane airplaneDTOToAirplane(AirplaneDTO airplaneDTO);
	
	AirlineDTO AirlineToSeatAirlineDTO(Airline airline);
	Airline airlineDTOToAirline(AirlineDTO airlineDTO);
	
	
}
