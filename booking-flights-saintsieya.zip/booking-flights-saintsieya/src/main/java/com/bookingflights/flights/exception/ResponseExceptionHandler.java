package com.bookingflights.flights.exception;


import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@ControllerAdvice
@RestController

public class ResponseExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(Exception.class)
    public final ResponseEntity<ExceptionResponse> manejarTodasExcepciones(Exception ex, WebRequest request) {
        ExceptionResponse er = new ExceptionResponse(LocalDateTime.now(), ex.getMessage(), request.getDescription(false));
        return new ResponseEntity<ExceptionResponse>(er, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(ModeloNotFoundException.class)
    public final ResponseEntity<ExceptionResponse> manejarModeloException(ModeloNotFoundException ex, WebRequest request) {
        ExceptionResponse er = new ExceptionResponse(LocalDateTime.now(), ex.getMessage(), request.getDescription(false));
        return new ResponseEntity<ExceptionResponse>(er, HttpStatus.NOT_FOUND);
    }
    
    @ExceptionHandler(DataIntegrityViolationException.class)
    public final ResponseEntity<ExceptionResponse> manejarJPAException(DataIntegrityViolationException ex, WebRequest request) {
    	
  
	 
        ExceptionResponse er = new ExceptionResponse(LocalDateTime.now(), ex.getRootCause().getLocalizedMessage(), request.getDescription(false));
        return new ResponseEntity<ExceptionResponse>(er, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
    @ExceptionHandler(ConstraintViolationException.class)
    public final ResponseEntity<ExceptionResponse> manejarModeloException(ConstraintViolationException ex, WebRequest request) {
        ExceptionResponse er = new ExceptionResponse(LocalDateTime.now(), ex.getMessage(), request.getDescription(false));
        return new ResponseEntity<ExceptionResponse>(er, HttpStatus.NOT_FOUND);
    }
    
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
    	
    
    	 StringBuilder sbuilder = new StringBuilder();
    	 
    	 sbuilder = obtenErrores( ex.getBindingResult().getFieldErrors(),ex.getBindingResult().getGlobalErrors());
        /*for (final FieldError error : ex.getBindingResult().getFieldErrors()) {
            errors.add(error.getField() + ": " + error.getDefaultMessage());
            sbuilder.append(error.getField() + ": " + error.getDefaultMessage());
        }
        for (final ObjectError error : ex.getBindingResult().getGlobalErrors()) {
        	 errors.add(error.getObjectName() + ": " + error.getDefaultMessage());
            errors.add(error.getObjectName() + ": " + error.getDefaultMessage());
        }*/
        
        //ExceptionResponse er = new ExceptionResponse(LocalDateTime.now(), ex.getMessage(), request.getDescription(false));
        ExceptionResponse er = new ExceptionResponse(LocalDateTime.now(), sbuilder.toString(), request.getDescription(false));
        return new ResponseEntity<Object>(er, HttpStatus.BAD_REQUEST);
    }
    
    private  StringBuilder obtenErrores(List<FieldError> ex, List<ObjectError> exobj) {
    	 StringBuilder sbuilder = new StringBuilder();
    	 final List<String> errors = new ArrayList<String>();
    	 for (final FieldError error : ex) {
             errors.add(error.getField() + ": " + error.getDefaultMessage());
             sbuilder.append(error.getField() + ": " + error.getDefaultMessage());
         }
         for (final ObjectError error : exobj) {
         	 errors.add(error.getObjectName() + ": " + error.getDefaultMessage());
             errors.add(error.getObjectName() + ": " + error.getDefaultMessage());
         }
    	 return sbuilder;
    }
}
