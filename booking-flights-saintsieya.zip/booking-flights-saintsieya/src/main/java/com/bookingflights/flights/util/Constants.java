package com.bookingflights.flights.util;

public final class Constants {

	//rol para usuarios registrados
	public static final String ROLE_GUEST = "GUEST";
	//rol para supervisor
	public static final String ROLE_SUPERVISOR = "SUPERVISOR";
	//rol para administrador de sistema
	public static final String ROLE_ADMIN = "ADMIN";
	
}
