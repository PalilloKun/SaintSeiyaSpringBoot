package com.bookingflights.flights.service.imp;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookingflights.flights.entity.TravelClass;
import com.bookingflights.flights.repository.TravelClassRepository;
import com.bookingflights.flights.service.TravelClassService;


@Service
public class TravelClassImp  implements TravelClassService{
	
	@Autowired
	TravelClassRepository travelclassRepository;

	@Override
	public TravelClass findById(Long id) {
		
		Optional<TravelClass>opt = travelclassRepository.findById(id);
		return opt.get();
	}

	@Override
	public List<TravelClass> findAll() {
		
		return travelclassRepository.findAll();
	}
	@Transactional
	@Override
	public TravelClass save(TravelClass e) {
		
		return travelclassRepository.save(e);
	}
	@Transactional
	@Override
	public TravelClass update(TravelClass e) {
		
		return travelclassRepository.save(e);
	}
	@Transactional
	@Override
	public void deleteById(Long id) throws Exception {
		travelclassRepository.deleteById(id);
		
	}

}
