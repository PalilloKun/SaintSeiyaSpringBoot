package com.bookingflights.flights.service;

import java.util.List;

import com.bookingflights.flights.entity.AirplaneCapacity;
import com.bookingflights.flights.service.ICRUD.ICRUD;

public interface AirplaneCapacityService  extends ICRUD<AirplaneCapacity>{

	List<AirplaneCapacity> findByIdAirplanecapacity(Long id);

}
