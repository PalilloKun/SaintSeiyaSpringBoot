package com.bookingflights.flights.DTO;


import lombok.Data;


@Data
public class SeatBookedDTO {

	private Long id;
	private TravelClassDTO travelClassDTO;
	private FlightDTO flightDTO;
	private Integer seats_booked;
}
