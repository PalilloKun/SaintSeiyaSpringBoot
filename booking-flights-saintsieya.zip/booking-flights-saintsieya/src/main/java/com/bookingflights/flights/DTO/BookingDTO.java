package com.bookingflights.flights.DTO;

import java.sql.Date;
import lombok.Data;

@Data
public class BookingDTO {
	
	
	private Long id;	
	private Date bookingSchelude;	
	private FlightDTO flightDTO;	
	private UserDTO user;	
	private TravelClassDTO travelClassDTO;	
	private Integer noTravelers;	
	private boolean status;
}
