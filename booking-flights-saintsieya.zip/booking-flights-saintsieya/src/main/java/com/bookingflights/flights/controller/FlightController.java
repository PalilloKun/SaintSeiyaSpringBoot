package com.bookingflights.flights.controller;


import java.sql.Date;
import java.util.List;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.bookingflights.flights.DTO.FlightDTO;
import com.bookingflights.flights.entity.Flight;
import com.bookingflights.flights.response.ExceptionResponse;
import com.bookingflights.flights.service.FlightService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/flights")
public class FlightController {
	
	@Autowired
	private FlightService flightService;
	
	
	
	
	 @ApiOperation(value = "Obtener la lista de todos los vuelos existentes en el sistema",
	            notes = "No necesita parametros de entrada",
	            response = List.class,
	            responseContainer = "Flight")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontraron  Vuelos en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Flight.class, responseContainer = "List")})
	@GetMapping
	public ResponseEntity<List<Flight>> listar(){
		
		List<Flight> lista = flightService.findAll();		
		return new ResponseEntity<List<Flight>>(lista, HttpStatus.OK);
	}	
	
	 
	 @ApiOperation(value = "Obtener un vuelo por su ID ",
	            notes = "Necesita el ID del vuelo",
	            response = Flight.class,
	            responseContainer = "Flight")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el Vuelo en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Flight.class, responseContainer = "Flight")})	
	@GetMapping("/{id}")
	public ResponseEntity <Flight> finbyid(@PathVariable("id") Long id){
		
		Flight lista = flightService.findById(id);		
		return new ResponseEntity<Flight>(lista, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para registrar nuevos Vuelos en el sistema ",
	            notes = "Necesita lnumbero de vuelo, id de origen, fecha de salida origen, id de destino, fecha de llegada destino, precio, booleano para alimentos gratis y para posibilidad de reembolso",
	            response = Flight.class,
	            responseContainer = "Flight")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el Vuelo en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Flight.class, responseContainer = "Flight")})	
	@PostMapping
	public ResponseEntity<Flight> registrar(@Valid @RequestBody Flight user) {				
		Flight obj = flightService.save(user);	
		return new ResponseEntity<Flight>(obj, HttpStatus.OK);
	}
	
	 
	 @ApiOperation(value = "Metodo para actualizar un vuelo en el sistema ",
	            notes = "Necesita  id del vuelo, como opcionales: numbero de vuelo, id de origen, fecha de salida origen, id de destino, fecha de llegada destino, precio, booleano para alimentos gratis y para posibilidad de reembolso",
	            response = Flight.class,
	            responseContainer = "Flight")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el Vuelo en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Flight.class, responseContainer = "Flight")})	
	@PutMapping
	public ResponseEntity<Flight> modificar(@Valid @RequestBody Flight user) {
		Flight obj = flightService.update(user);
		return new ResponseEntity<Flight>(obj, HttpStatus.OK);
	}
	

	 @ApiOperation(value = "Metodo para eliminar un vuelo",
	            notes = "Necesita id",
	            response = HttpStatus.class,
	            responseContainer = "HttpStatus")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se tiene permiso para realizar esta accion", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = HttpStatus.class, responseContainer = "HttpStatus")})
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> eliminar(@PathVariable("id") Long id) throws Exception {
		flightService.deleteById(id);
		return new ResponseEntity<Object>(HttpStatus.OK);
	}
	 
	 
	 @ApiOperation(value = "Metodo para obtener vuelos de acuerdo a un rango de fechas inicial y final",
            notes = "Necesita fecha start y fecha end",
            response = List.class,
            responseContainer = "Flight")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
            @ApiResponse(code = 405, message = "No se encontraron  Vuelos en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Flight.class, responseContainer = "List")})
	 @GetMapping("/buscarfechas/{ini}/{end}")
	public ResponseEntity<List<Flight>> buscafechas(@PathVariable("ini") Date ini,@PathVariable("end") Date end ) throws Exception {
	 
	 	List<Flight> lista = flightService.customBetweenDates(ini, end);		
		return new ResponseEntity<List<Flight>>(lista, HttpStatus.OK);
	}
	 
	 
	 @ApiOperation(value = "Metodo para obtener vuelos de acuerdo a una busqueda especifica",
	            notes = "Necesita fecha start y fecha end como obligatorios, parametros opcionales {locstart}(locacion de origen), {locend}(locacion de destino),  {locend}(locacion de destino)",
	            response = List.class,
	            responseContainer = "Flight")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontraron  Vuelos en el sistema", response = ExceptionResponse.class),
		            @ApiResponse(code = 200, message = "Peticón OK", response = Flight.class, responseContainer = "List")})
	 @GetMapping("/buscarcomplejo/start/{ini}/end/{end}")
		public ResponseEntity<List<FlightDTO>> buscarcomplejo( @ApiParam(name = "ini", value = "Fecha de inicio", defaultValue = "") @PathVariable("ini") Date ini ,
				@ApiParam(name = "end", value = "Fecha de final", defaultValue = "") @PathVariable("end") Date end,
				@ApiParam(name = "locstart", value = "Ubicacion de Depart", defaultValue = "") @RequestParam(name = "locstart", required = false) Integer locstart,
				@ApiParam(name = "locend", value = "Ubicacion de Arrive", defaultValue = "") @RequestParam(name = "locend", required = false) Integer locend,
				@ApiParam(name = "meals", value = "Booleano alimentos gratis", defaultValue = "") @RequestParam(name = "meals", required = false) Boolean meals,
				@ApiParam(name = "refund", value = "Booleano refund disponible", defaultValue = "") @RequestParam(name = "refund", required = false) Boolean refund) throws Exception {
		 
			StringBuilder stringquery = new StringBuilder();
			stringquery.append(" SELECT f.id_flight, f.flight_number, f.price, f.free_meals, f.refundable, f.datetime_depart, f.location_depart_id, f.datetime_arrive, f.location_arrive_id FROM flight f ");
			if(locstart != null ) {
				stringquery.append(" INNER JOIN location ld ON f.location_depart_id = ld.id_location ");				
			}
			if(locend != null ) {
				stringquery.append(" INNER JOIN location la ON f.location_depart_id = la.id_location ");				
			}
			stringquery.append(" WHERE  f.datetime_depart >= '"+ini+"' AND f.datetime_arrive <= '"+end+"' ");
			
			if(locstart != null ) {
				stringquery.append(" AND f.location_depart_id =  "+locstart+" ");				
			}
			if(locend != null ) {
				stringquery.append("  AND f.datetime_arrive  =  "+locend+" ");				
			}
			if(meals != null ) {
				stringquery.append("  AND f.free_meals  =  "+meals+" ");				
			}
			if(refund != null ) {
				stringquery.append("  AND f.refundable  =  "+refund+" ");				
			}			
			List<FlightDTO> lista = flightService.customComplexQuery(stringquery.toString());
			
			return new ResponseEntity<List<FlightDTO>>(lista, HttpStatus.OK);
		}

}
