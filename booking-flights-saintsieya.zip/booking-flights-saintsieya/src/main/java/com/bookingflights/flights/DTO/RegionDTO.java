package com.bookingflights.flights.DTO;

import lombok.Data;

@Data
public class RegionDTO {

	private Long idRegion;
	private String name;
}
