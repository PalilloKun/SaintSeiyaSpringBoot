package com.bookingflights.flights.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Entity
@Table(name = "seats_booked")
@ApiModel(description = "Información o propiedes del Seats Booked")
@Data
public class SeatBooked {

	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_seats_booked")
	private Long idSeatBooked;
	
	@ApiModelProperty(notes ="ID del Tipo de Clase ",required=true)   
	@ManyToOne
    @JoinColumn(name = "id_travel_class", nullable = false)
	private TravelClass travel_class;
	
	@ApiModelProperty(notes = "ID del Flight",required=true)
	@ManyToOne
    @JoinColumn(name = "id_flight", nullable = false)
	private Flight flight;
	
	@ApiModelProperty(notes = "Numero de asientos reservados",required=true)
    @Min(value =1,message="Minimo un asiento a reservar")
	@Column(name = "seats_booked")
	private Integer seats_booked;

	
}
