package com.bookingflights.flights.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bookingflights.flights.entity.AirplaneCapacity;

@Repository
public interface AirplaneCapacityRepository  extends JpaRepository<AirplaneCapacity,Long>{

	
	List<AirplaneCapacity> findByIdAirplanecapacity(Long idAirplanecapacity); //findPacienteByDniAndNombres(String dni, String nombres);
}
