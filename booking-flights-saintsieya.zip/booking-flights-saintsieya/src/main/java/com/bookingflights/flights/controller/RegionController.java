package com.bookingflights.flights.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bookingflights.flights.entity.Region;
import com.bookingflights.flights.response.ExceptionResponse;
import com.bookingflights.flights.service.RegionService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/regions")
public class RegionController {

	@Autowired
	private RegionService regionService;
	
	
	 @ApiOperation(value = "Obtener la lista de regiones de los vuelos",
	            notes = "No necesita parametros de entrada",
	            response = List.class,
	            responseContainer = "Region")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontraron  Regiones en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Region.class, responseContainer = "List")})
	@GetMapping
	public ResponseEntity<List<Region>> listar(){
		
		List<Region> lista = regionService.findAll();		
		return new ResponseEntity<List<Region>>(lista, HttpStatus.OK);
	}	
	 
	 @ApiOperation(value = "Obtener la informacion de la Region por su ID ",
	            notes = "Necesita el ID del usuario",
	            response = Region.class,
	            responseContainer = "Region")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro la Region en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Region.class, responseContainer = "Region")})	
	@GetMapping("/{id}")
	public ResponseEntity <Region> finbyid(@PathVariable("id") Long id){
		
		Region lista = regionService.findById(id);		
		return new ResponseEntity<Region>(lista, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para registrar nuevas Regiones en el sistema ",
	            notes = "Necesita el nombre",
	            response = Region.class,
	            responseContainer = "Region")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el Tipo de Clase en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Region.class, responseContainer = "Region")})	
	@PostMapping
	public ResponseEntity<Region> registrar(@Valid @RequestBody Region user) {		
		Region obj = regionService.save(user);	
		return new ResponseEntity<Region>(obj, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para actualizar Regiones en el sistema ",
	            notes = "Necesita el id",
	            response = Region.class,
	            responseContainer = "Region")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el Tipo de Clase en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Region.class, responseContainer = "Region")})	
	@PutMapping
	public ResponseEntity<Region> modificar(@Valid @RequestBody Region user) {
		Region obj = regionService.update(user);
		return new ResponseEntity<Region>(obj, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para eliminar Region",
	            notes = "Necesita id",
	            response = HttpStatus.class,
	            responseContainer = "HttpStatus")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se tiene permiso para realizar esta accion", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = HttpStatus.class, responseContainer = "HttpStatus")})
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> eliminar(@PathVariable("id") Long id) throws Exception {
		regionService.deleteById(id);
		return new ResponseEntity<Object>(HttpStatus.OK);
	}
}
