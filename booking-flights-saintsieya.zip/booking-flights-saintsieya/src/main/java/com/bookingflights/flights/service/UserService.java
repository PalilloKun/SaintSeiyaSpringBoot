package com.bookingflights.flights.service;


import  com.bookingflights.flights.entity.User;
import com.bookingflights.flights.service.ICRUD.ICRUD;


public interface UserService extends  ICRUD<User>{ 

	
	
}
