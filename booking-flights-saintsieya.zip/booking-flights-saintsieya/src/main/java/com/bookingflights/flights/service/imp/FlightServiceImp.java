package com.bookingflights.flights.service.imp;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookingflights.flights.DTO.FlightDTO;
import com.bookingflights.flights.DTO.LocationDTO;
import com.bookingflights.flights.entity.Flight;
import com.bookingflights.flights.repository.FlightRepository;
import com.bookingflights.flights.service.FlightService;

@Service
public class FlightServiceImp implements FlightService{
	
	@Autowired
	FlightRepository flightRepository;
	
	 @PersistenceContext
	 public EntityManager em;

	@Override
	public Flight findById(Long id) {
		Optional<Flight>opt = flightRepository.findById(id);
		return opt.get();
	}

	@Override
	public List<Flight> findAll() {
		
		return flightRepository.findAll();
	}
	
	@Transactional(rollbackOn = {RuntimeException.class})
	@Override
	public Flight save(Flight e) {
		
		return flightRepository.save(e);
	}
	
	@Transactional(rollbackOn = {RuntimeException.class})
	@Override
	public Flight update(Flight e) {
		
		return flightRepository.save(e);
	}
	
	@Transactional(rollbackOn = {RuntimeException.class})
	@Override
	public void deleteById(Long id) throws Exception {
		
		flightRepository.deleteById(id);
		
	}

	@Override
	public List<Flight> customBetweenDates(Date ini, Date end) {
		
		return flightRepository.customBetweenDates(ini, end);
	}

	
	
	
	@Override
	public List<FlightDTO> customComplexQuery(String QUERY) {
		
		List<FlightDTO> fDTO = new ArrayList<>();
		Query q = em.createNativeQuery(QUERY);
	 	List<Object[]> results = q.getResultList();
	 	 
	 	results.forEach(x ->{
	 		FlightDTO d = new FlightDTO();
	 		
	 		d.setIdFlight(Long.valueOf(String.valueOf(x[0]))  );
	 		d.setFlightNumber(String.valueOf(x[1]));
	 		d.setPrice(Long.valueOf(String.valueOf(x[2]))  );
	 		d.setFreeMeals(Boolean.valueOf( String.valueOf(x[3])));
	 		d.setRefundable(Boolean.valueOf( String.valueOf(x[4])));		 		
	 	
	 		String departDate = String.valueOf(x[5]);
	 		Date date=Date.valueOf(departDate);
			d.setDatetimeDepart(date );
			
			d.setLocationDepart(new LocationDTO(Long.valueOf(String.valueOf(x[6]))  ));
			
			String arrivDate = String.valueOf(x[7]);
	 		Date arriveDate=Date.valueOf(arrivDate);
			d.setDatetimeArrive(arriveDate );
			
			d.setLocationArrive(new LocationDTO(Long.valueOf(String.valueOf(x[8]))  ));
	 		
	 		
	 		fDTO.add(d);
	 	});
		
		return fDTO;
	}

}
