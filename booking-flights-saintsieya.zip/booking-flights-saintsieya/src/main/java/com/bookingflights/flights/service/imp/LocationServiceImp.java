package com.bookingflights.flights.service.imp;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookingflights.flights.entity.Location;
import com.bookingflights.flights.repository.LocationRepository;
import com.bookingflights.flights.service.LocationService;

@Service
public class LocationServiceImp  implements LocationService{
	
	@Autowired
	LocationRepository locationRepository;
	
	@Override
	public Location findById(Long id) {
		Optional<Location>opt = locationRepository.findById(id);
		return opt.get();
		
	}

	@Override
	public List<Location> findAll() {
		
		return locationRepository.findAll();
	}
	@Transactional
	@Override
	public Location save(Location e) {
		
		return locationRepository.save(e);
	}
	@Transactional
	@Override
	public Location update(Location e) {
		
		return locationRepository.save(e);
	}

	@Transactional
	@Override
	public void deleteById(Long id) throws Exception {
		locationRepository.deleteById(id);
		
	}

}
