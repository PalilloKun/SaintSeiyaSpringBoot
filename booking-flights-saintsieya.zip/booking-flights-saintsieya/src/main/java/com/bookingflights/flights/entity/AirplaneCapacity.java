package com.bookingflights.flights.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Entity
@ApiModel(description = "Información o propiedes de AirplaneCapacity")
@Data
@Table(name = "airplane_capacity",
	   uniqueConstraints={
			   @UniqueConstraint(columnNames = {"id_airplane" , "id_travel_class"})
	  }
)
public class AirplaneCapacity {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_airplane_capacity")
	private Long idAirplanecapacity;
	
	@ApiModelProperty(notes = "Capacidad del Airplane",required=true)   
	@NotNull(message="Valor requerido")
	@Column(name = "capacity")
	private Integer capacity;
	
	@ApiModelProperty(notes = "ID del Airplane",required=true)   
	@ManyToOne
    @JoinColumn(name = "id_airplane", nullable = false)
	private Airplane airplane;
	
	@ApiModelProperty(notes = "ID del Travel Class",required=true)   
	@ManyToOne
    @JoinColumn(name = "id_travel_class", nullable = false)
	private TravelClass travelclass;

	

}
