package com.bookingflights.flights.exception;


public class ModeloNotFoundException extends RuntimeException{

    public ModeloNotFoundException(String message) {
        super(message);
    }
}
