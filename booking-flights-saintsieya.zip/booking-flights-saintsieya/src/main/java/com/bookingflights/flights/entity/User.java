package com.bookingflights.flights.entity;


import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "users")
@ApiModel(description = "Información o propiedes del User")
@Setter
@Getter
public class User {
	
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_user")
	private Long idUser;
	
	@ApiModelProperty(notes = "Password del User",required=true)
    @Size(min = 8, max = 250, message = "El password debe ser mayor a 8 caracteres y menos a 250")
	@Column(name = "password")	
	private String password;
	
	@ApiModelProperty(notes = "Nombre inicial User",required=true)
    @Size(min = 5, max = 100, message = "El nombre debe ser mayor a 5 caracteres y menor a 100")
	@Column(name = "name")
	private String name;
	
	@ApiModelProperty(notes = "Nombre secundario del User (opcional)",required=false)
    @Size(min = 2, max = 100, message = "El segundo nombre debe ser mayor a 2 caracteres y menor a 100")
	@Column(name = "middle_name",nullable=true)
	private String middle_name;
	
	@ApiModelProperty(notes = "Apellido Paterno del User",required=true)
	@Size(min = 5, max = 100, message = "El Apellido Paterno debe ser mayor a 5 caracteres y menor a 100")
	@Column(name = "surname")	
	private String surname;
	
	@ApiModelProperty(notes = "Apellido Materno del User (opcional)",required=false,allowEmptyValue=false)
	@Size(min = 5, max = 100, message = "El Apellido Materno debe ser mayor a 5 caracteres y menor a 100")
	@Column(name = "last_name")	
	private String last_name;
	
	@ApiModelProperty(notes = "Genero requerido del User",required=true)	
	@OneToOne
	@JoinColumn(name = "id_genre", nullable = false)
	private Genre genre;
	
	
	@ApiModelProperty(notes = "La direccion del User",required=true)
	@Size(min = 10, max = 200, message = "la direccion  debe ser mayor a  a 5 caracteres y menor a 200")
	@Column(name = "address")	
	private String address;
	
	@ApiModelProperty(notes = "El email del User",required=true)
	@Email(message = "El email debe ser de tipo email")
	@Column(name = "email",unique=true)
	private String email;
	
	@ApiModelProperty(notes = "El telefono del User",required=true,allowableValues = "range[1000000000,999999999999999]")
	@Size(min = 10, max = 15, message = "El telefono debe ser mayor a 10 caracteres y menor a 15")
	@Pattern(regexp = "[0-9]*", message = "Solo numeros")
	@Column(name = "phone_number")	
	private String phone_number;
	
	@ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "user_role",
            joinColumns = @JoinColumn(name = "id_user", referencedColumnName = "id_user"),
            inverseJoinColumns = @JoinColumn(name = "id_role", referencedColumnName = "id_role"))
	//@NotBlank(message = "El rol es necesario")
    private List<Role> rols;
	
	
	
	//Reverse relation
	 @OneToMany(mappedBy="user",cascade=CascadeType.ALL,  orphanRemoval = true)	
	 @JsonManagedReference
	 private List<Booking> booking;



	
}
