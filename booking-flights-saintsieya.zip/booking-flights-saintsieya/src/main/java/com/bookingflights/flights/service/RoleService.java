package com.bookingflights.flights.service;

import org.springframework.stereotype.Service;

import com.bookingflights.flights.entity.Role;
import com.bookingflights.flights.service.ICRUD.ICRUD;


@Service
public interface RoleService  extends  ICRUD<Role>{

}
