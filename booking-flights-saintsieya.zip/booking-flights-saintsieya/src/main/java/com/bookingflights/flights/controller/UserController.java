package com.bookingflights.flights.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.oauth2.client.test.OAuth2ContextConfiguration.Password;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;

import com.bookingflights.flights.DTO.UserDTO;
import com.bookingflights.flights.entity.User;
import com.bookingflights.flights.facades.AllFacadeServices;
import com.bookingflights.flights.response.ExceptionResponse;
import com.bookingflights.flights.service.UserService;


import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


import javax.validation.Valid;

@RestController
@RequestMapping("/users")
public class UserController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private AllFacadeServices allfacades;

	 @ApiOperation(value = "Obtener todos los usuarios registrados en el sistema",
	            notes = "No necesita parametros de entrada",
	            response = List.class,
	            responseContainer = "User")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontraron usuarios en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = User.class, responseContainer = "List")})
	@GetMapping
	public ResponseEntity<List<User>> listar(){
		
		List<User> lista = allfacades.userService.findAll();
		
		
		
		return new ResponseEntity<List<User>>(lista, HttpStatus.OK);
	}
	 
	/*
	@ApiOperation(value = "Obtener todos los usuarios registrados en el sistema",
            notes = "No necesita parametros de entrada",
            response = List.class,
            responseContainer = "User")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
            @ApiResponse(code = 405, message = "No se encontraron usuarios en el sistema", response = ExceptionResponse.class),
            @ApiResponse(code = 200, message = "Peticón OK", response = User.class, responseContainer = "List")})
	@GetMapping
	public ResponseEntity<List<UserDTO>> listar(){
		
		List<UserDTO> lista = allfacades.findAll();
		
		
		
		return new ResponseEntity<List<UserDTO>>(lista, HttpStatus.OK);
	}
	*/
	
	 @ApiOperation(value = "Obtener el usuario por su ID ",
	            notes = "Necesita el ID del usuario",
	            response = User.class,
	            responseContainer = "User")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el usuario en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = User.class, responseContainer = "User")})	
	@GetMapping("/{id}")
	public ResponseEntity <User> finbyid(@PathVariable("id") Long id) throws Exception{
		
		User lista = userService.findById(id);
		
		return new ResponseEntity<User>(lista, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para dar de alta un nuevo usuario en el sistema ",
	            notes = "Necesita name,password,middle_name,surname,last_name,genre,address,email,phone_number",
	            response = User.class,
	            responseContainer = "User")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se tiene permiso para realizar esta accion", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = User.class, responseContainer = "User")})
	@PostMapping
	public ResponseEntity<User> registrar(@Valid @RequestBody User user) throws Exception{		
		
		  BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		 
		  user.setPassword(encoder.encode(user.getPassword()).toString());
		 
		  User obj = userService.save(user);	
		return new ResponseEntity<User>(obj, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para modificar un usuario en el sistema ",
	            notes = "Necesita id, name,password,middle_name,surname,last_name,genre,address,email,phone_number",
	            response = User.class,
	            responseContainer = "User")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se tiene permiso para realizar esta accion", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = User.class, responseContainer = "User")})
	@PutMapping
	public ResponseEntity<User> modificar(@Valid @RequestBody User user) throws Exception{
		User obj = userService.update(user);
		return new ResponseEntity<User>(obj, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para eliminar un usuario del sistema ",
	            notes = "Necesita id",
	            response = HttpStatus.class,
	            responseContainer = "HttpStatus")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se tiene permiso para realizar esta accion", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = HttpStatus.class, responseContainer = "HttpStatus")})
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> eliminar(@PathVariable("id") Long id) throws Exception {
		userService.deleteById(id);
		return new ResponseEntity<Object>(HttpStatus.OK);
	}
	 
	 @GetMapping("/getAll")
		public ResponseEntity<List<User>> getAll(){
			List<User> lista = userService.findAll();
			return new ResponseEntity<List<User>>(lista, HttpStatus.OK);
		}
}
