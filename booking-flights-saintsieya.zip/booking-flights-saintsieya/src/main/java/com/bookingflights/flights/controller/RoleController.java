package com.bookingflights.flights.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bookingflights.flights.entity.Role;
import com.bookingflights.flights.response.ExceptionResponse;
import com.bookingflights.flights.service.RoleService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/roles")
public class RoleController {

	@Autowired
	private RoleService roleService;
	
	
	 @ApiOperation(value = "Obtener la lista de los roles",
	            notes = "No necesita parametros de entrada",
	            response = List.class,
	            responseContainer = "Role")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontraron  el  Role en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Role.class, responseContainer = "List")})
	@GetMapping
	public ResponseEntity<List<Role>> listar(){
		
		List<Role> lista = roleService.findAll();		
		return new ResponseEntity<List<Role>>(lista, HttpStatus.OK);
	}	
	
	 
	 @ApiOperation(value = "Obtener la informacion del Role por ID ",
	            notes = "Necesita el ID del Role",
	            response = Role.class,
	            responseContainer = "Role")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el  Role en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Role.class, responseContainer = "Role")})	
	@GetMapping("/{id}")
	public ResponseEntity <Role> finbyid(@PathVariable("id") Long id){
		
		 Role lista = roleService.findById(id);		
		return new ResponseEntity<Role>(lista, HttpStatus.OK);
	}
	

	 @ApiOperation(value = "Metodo para registrar nuevos Role ",
	            notes = "Necesita el nombre del Role",
	            response = Role.class,
	            responseContainer = "Role")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el Role el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Role.class, responseContainer = "Role")})	
	@PostMapping
	public ResponseEntity<Role> registrar(@Valid @RequestBody Role role) {		
		 System.out.println("el name "+role.getName());
		 Role obj = roleService.save(role);	
		return new ResponseEntity<Role>(obj, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para actualizar el Role en el sistema",
	            notes = "Necesita el id ",
	            response = Role.class,
	            responseContainer = "RoleClass")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se encontro el Role en el sistema", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = Role.class, responseContainer = "Role")})	
	@PutMapping
	public ResponseEntity<Role> modificar(@Valid @RequestBody Role role) {
		 Role obj = roleService.update(role);
		return new ResponseEntity<Role>(obj, HttpStatus.OK);
	}
	
	 @ApiOperation(value = "Metodo para eliminar Role en el sistema ",
	            notes = "Necesita id",
	            response = HttpStatus.class,
	            responseContainer = "HttpStatus")
	    @ApiResponses(value = {
	            @ApiResponse(code = 400, message = "Bad request o datos no enviados correctamente", response = ExceptionResponse.class),
	            @ApiResponse(code = 404, message = "Not found, no encontrado", response = ExceptionResponse.class),
	            @ApiResponse(code = 405, message = "No se tiene permiso para realizar esta accion", response = ExceptionResponse.class),
	            @ApiResponse(code = 200, message = "Peticón OK", response = HttpStatus.class, responseContainer = "HttpStatus")})
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> eliminar(@PathVariable("id") Long id) throws Exception {
		 roleService.deleteById(id);
		return new ResponseEntity<Object>(HttpStatus.OK);
	}
}
