package com.bookingflights.flights.DTO;


import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UserDTO {
	

	private Long id;
	private String password;
	private String name;	
	private String middle_name;
	private String surname;
	private String last_name;	
	private GenreDTO genre;
	private String address;	
	private String email;	
	private String phone_number;	
}
