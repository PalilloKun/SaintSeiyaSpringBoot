
create  table if not exists oauth_access_token (
token_id VARCHAR(256),
token bytea,
authentication_id VARCHAR(256),
user_name VARCHAR(256),
client_id VARCHAR(256),
authentication bytea,
refresh_token VARCHAR(256)
);

create table if not exists oauth_refresh_token (
  token_id VARCHAR(256),
  token bytea,
  authentication bytea
);

CREATE OR REPLACE function random_between(low int, high int)
RETURNS integer AS '
declare
  total integer;
BEGIN
    RETURN floor(random()* (high-low + 1) + low);
END;
' LANGUAGE plpgsql; 

/*datos de prueba*/


CREATE OR REPLACE function insert_data_roles_s()
RETURNS VOID 
AS '
DECLARE
	rolesZ integer;
BEGIN 
	  SELECT COUNT(*) INTO rolesZ FROM role;	  
	  IF rolesZ = 0 THEN
	  	INSERT INTO role(name)VALUES(''GUEST'');
		INSERT INTO role(name)VALUES(''SUPERVISOR'');
		INSERT INTO role(name)VALUES(''ADMIN'');
	  END IF;
 END;
' LANGUAGE plpgsql; 

SELECT insert_data_roles_s();

CREATE OR REPLACE function insert_data_genre_s()
RETURNS VOID 
AS '
DECLARE
	genr integer;
BEGIN 
	  SELECT COUNT(*) INTO genr FROM genre;	  
	  IF genr = 0 THEN
	  	INSERT INTO genre(description,status)VALUES(''Male'',true);
		INSERT INTO genre(description,status)VALUES(''Female'',true);
	  END IF;
 END;
' LANGUAGE plpgsql; 

SELECT insert_data_genre_s();


CREATE OR REPLACE function insert_data_travel_class_s()
RETURNS VOID 
AS '
DECLARE
	travel_clas integer;
BEGIN 
	  SELECT COUNT(*) INTO travel_clas FROM travel_class;	  
	  IF travel_clas = 0 THEN
	  	INSERT INTO travel_class(name)VALUES(''Economic'');
		INSERT INTO travel_class(name)VALUES(''Premium'');
		INSERT INTO travel_class(name)VALUES(''Business'');
		INSERT INTO travel_class(name)VALUES(''First Class'');
	  END IF;
 END;
' LANGUAGE plpgsql; 

SELECT insert_data_travel_class_s();

CREATE OR REPLACE function insert_data_region_s()
RETURNS VOID 
AS '
DECLARE
	regio integer;
BEGIN 
	  SELECT COUNT(*) INTO regio FROM region;	  
	  IF regio = 0 THEN
	  	INSERT INTO region(name)VALUES(''Underworld'');
		INSERT INTO region(name)VALUES(''Elysium'');
		INSERT INTO region(name)VALUES(''Athena Sanctuary'');
		INSERT INTO region(name)VALUES(''Atlantis'');
		INSERT INTO region(name)VALUES(''Earth'');
		INSERT INTO region(name)VALUES(''Heaven'');
	  END IF;
 END;
' LANGUAGE plpgsql; 

SELECT insert_data_region_s();


CREATE OR REPLACE function insert_data_region_s()
RETURNS VOID 
AS '
DECLARE
	locatio integer;
BEGIN 
	  SELECT COUNT(*) INTO locatio FROM location;	  
	  IF locatio = 0 THEN
	  	INSERT INTO location(name,id_region)VALUES(''Hells Gate'',1);
		INSERT INTO location(name,id_region)VALUES(''Acheron River'',1);
		INSERT INTO location(name,id_region)VALUES(''Hall of Judgement'',1);
		INSERT INTO location(name,id_region)VALUES(''Dark Valley of the Wind'',1);
		INSERT INTO location(name,id_region)VALUES(''Flower Field'',1);
		INSERT INTO location(name,id_region)VALUES(''Gluttony'',1);
		INSERT INTO location(name,id_region)VALUES(''Greed & Squander'',1);
		INSERT INTO location(name,id_region)VALUES(''Anger & Laziness'',1);
		INSERT INTO location(name,id_region)VALUES(''Heresy'',1);
		INSERT INTO location(name,id_region)VALUES(''Walls of the City of Dis'',1);
		INSERT INTO location(name,id_region)VALUES(''Labyrinth of the Minotaur'',1);
		INSERT INTO location(name,id_region)VALUES(''Violence'',1);
		INSERT INTO location(name,id_region)VALUES(''Great Waterfall of Blood'',1);
		INSERT INTO location(name,id_region)VALUES(''Fraud'',1);
		INSERT INTO location(name,id_region)VALUES(''Treachery'',1);
		INSERT INTO location(name,id_region)VALUES(''Caina'',1);
		INSERT INTO location(name,id_region)VALUES(''Antenora'',1);
		INSERT INTO location(name,id_region)VALUES(''Elysian Fields'',2);
		INSERT INTO location(name,id_region)VALUES(''Colosseum'',3);
		INSERT INTO location(name,id_region)VALUES(''The Fire Clock'',3);
		INSERT INTO location(name,id_region)VALUES(''Saint Graveyard'',3);
		INSERT INTO location(name,id_region)VALUES(''Chamber of the Seal'',3);
		INSERT INTO location(name,id_region)VALUES(''Aries Temple'',3);
		INSERT INTO location(name,id_region)VALUES(''Taurus Temple'',3);
		INSERT INTO location(name,id_region)VALUES(''Gemini Temple'',3);
		INSERT INTO location(name,id_region)VALUES(''Cancer Temple'',3);
		INSERT INTO location(name,id_region)VALUES(''Leo Temple'',3);
		INSERT INTO location(name,id_region)VALUES(''Virgo Temple'',3);
		INSERT INTO location(name,id_region)VALUES(''Libra Temple'',3);
		INSERT INTO location(name,id_region)VALUES(''Scorpio Temple'',3);
		INSERT INTO location(name,id_region)VALUES(''Sagittarius Temple'',3);
		INSERT INTO location(name,id_region)VALUES(''Capricorn Temple'',3);
		INSERT INTO location(name,id_region)VALUES(''Aquarius Temple'',3);
		INSERT INTO location(name,id_region)VALUES(''Pisces Temple'',3);
		INSERT INTO location(name,id_region)VALUES(''The Popes Chamber'',3);
		INSERT INTO location(name,id_region)VALUES(''The Temple of Poseidon'',4);
		INSERT INTO location(name,id_region)VALUES(''North Pacific Oceans Pillar'',4);
		INSERT INTO location(name,id_region)VALUES(''South Pacific Ocean Pillar'',4);
		INSERT INTO location(name,id_region)VALUES(''Indian Ocean pillar'',4);
		INSERT INTO location(name,id_region)VALUES(''Antarctic Ocean pillar.'',4);
		INSERT INTO location(name,id_region)VALUES(''Arctic Ocean pillar'',4);
		INSERT INTO location(name,id_region)VALUES(''North Atlantic pillar'',4);
		INSERT INTO location(name,id_region)VALUES(''South Atlantic pillar'',4);
		INSERT INTO location(name,id_region)VALUES(''Jamir'',5);
		INSERT INTO location(name,id_region)VALUES(''Lushan'',5);
		INSERT INTO location(name,id_region)VALUES(''Heaven'',6);
	  END IF;
 END;
' LANGUAGE plpgsql; 

SELECT insert_data_region_s();



CREATE OR REPLACE function insert_data_airline_s()
RETURNS VOID 
AS '
DECLARE
	airlin integer;
BEGIN 
	  SELECT COUNT(*) INTO airlin FROM airline;	  
	  IF airlin = 0 THEN
	  	INSERT INTO airline(name,short_name,logo)VALUES(''Hades Airlines'',''HARLS'', ''hades.png'');
		INSERT INTO airline(name,short_name,logo)VALUES(''Saori Airways'',''SAWYS'', ''saori.png'');
		INSERT INTO airline(name,short_name,logo)VALUES(''Poseidon Pacifics'',''POPCS'', ''poseidon.png'');
		INSERT INTO airline(name,short_name,logo)VALUES(''Elysium Jet'',''ELYJT'', ''elysium.png'');
		INSERT INTO airline(name,short_name,logo)VALUES(''Heaven Wings'',''HEWG'', ''heaven.png'');
	  END IF;
 END;
' LANGUAGE plpgsql; 

SELECT insert_data_airline_s();


CREATE OR REPLACE function insert_data_airplane_s()
RETURNS VOID 
AS '
DECLARE
	airplan integer;
BEGIN 
	  SELECT COUNT(*) INTO airplan FROM airplane;	  
	  IF airplan = 0 THEN
	  	INSERT INTO airplane(id_airline)VALUES(1);
		INSERT INTO airplane(id_airline)VALUES(2);
		INSERT INTO airplane(id_airline)VALUES(3);
		INSERT INTO airplane(id_airline)VALUES(4);
		INSERT INTO airplane(id_airline)VALUES(5);
	  END IF;
 END;
' LANGUAGE plpgsql; 

SELECT insert_data_airplane_s();


CREATE OR REPLACE function insert_airplane_capacity_s()
RETURNS VOID 
AS '
DECLARE
	airplane_capacit integer;
BEGIN 
	  SELECT COUNT(*) INTO airplane_capacit FROM airplane_capacity;	  
	  IF airplane_capacit = 0 THEN
	  	INSERT INTO airplane_capacity(capacity,id_airplane,id_travel_class)VALUES(10,1, 4);
		INSERT INTO airplane_capacity(capacity,id_airplane,id_travel_class)VALUES(20,1, 3);
		INSERT INTO airplane_capacity(capacity,id_airplane,id_travel_class)VALUES(50,1, 2);
		INSERT INTO airplane_capacity(capacity,id_airplane,id_travel_class)VALUES(050,1, 1);
		
		INSERT INTO airplane_capacity(capacity,id_airplane,id_travel_class)VALUES(10,2, 4);
		INSERT INTO airplane_capacity(capacity,id_airplane,id_travel_class)VALUES(20,2, 3);
		INSERT INTO airplane_capacity(capacity,id_airplane,id_travel_class)VALUES(50,2, 2);
		INSERT INTO airplane_capacity(capacity,id_airplane,id_travel_class)VALUES(100,2, 1);
		
		INSERT INTO airplane_capacity(capacity,id_airplane,id_travel_class)VALUES(10,3, 4);
		INSERT INTO airplane_capacity(capacity,id_airplane,id_travel_class)VALUES(20,3, 3);
		INSERT INTO airplane_capacity(capacity,id_airplane,id_travel_class)VALUES(50,3, 2);
		INSERT INTO airplane_capacity(capacity,id_airplane,id_travel_class)VALUES(250,3, 1);
		
		INSERT INTO airplane_capacity(capacity,id_airplane,id_travel_class)VALUES(10,4, 4);
		INSERT INTO airplane_capacity(capacity,id_airplane,id_travel_class)VALUES(20,4, 3);
		INSERT INTO airplane_capacity(capacity,id_airplane,id_travel_class)VALUES(50,4, 2);
		INSERT INTO airplane_capacity(capacity,id_airplane,id_travel_class)VALUES(70,4, 1);
	  END IF;
 END;
' LANGUAGE plpgsql; 

SELECT insert_airplane_capacity_s();


CREATE OR REPLACE function insert_flight_s()
RETURNS VOID 
AS '
DECLARE
	fligh integer;
BEGIN 
	  SELECT COUNT(*) INTO fligh FROM flight;	  
	  IF fligh = 0 THEN
	  	INSERT INTO flight(flight_number,location_depart_id,datetime_depart,location_arrive_id,datetime_arrive,price,free_meals,refundable)VALUES(random_between(1000,9999),1,''2021-09-15 10:30:15'',
		2,''2021-09-15 14:50:00'',150,false,false);
		INSERT INTO flight(flight_number,location_depart_id,datetime_depart,location_arrive_id,datetime_arrive,price,free_meals,refundable)VALUES(random_between(1000,9999),1,''2021-09-15 11:00:15'',
		3,''2021-09-15 14:00:00'',165,false,false);
		INSERT INTO flight(flight_number,location_depart_id,datetime_depart,location_arrive_id,datetime_arrive,price,free_meals,refundable)VALUES(random_between(1000,9999),2,''2021-09-15 11:00:15'',
		6,''2021-09-15 17:00:00'',125,false,false);
		INSERT INTO flight(flight_number,location_depart_id,datetime_depart,location_arrive_id,datetime_arrive,price,free_meals,refundable)VALUES(random_between(1000,9999),7,''2021-09-16 04:00:15'',
		18,''2021-09-21 19:00:00'',465,true,true);
		INSERT INTO flight(flight_number,location_depart_id,datetime_depart,location_arrive_id,datetime_arrive,price,free_meals,refundable)VALUES(random_between(1000,9999),19,''2021-09-19 08:00:15'',
		1,''2021-09-22 20:00:00'',365,true,true);
	  END IF;
 END;
' LANGUAGE plpgsql; 

SELECT insert_flight_s();

/*PASSSWORD: HOLA1231  */

CREATE OR REPLACE function insert_users_s()
RETURNS VOID 
AS '
DECLARE
	userss integer;
BEGIN 
	  SELECT COUNT(*) INTO userss FROM users;	  
	  IF userss = 0 THEN
	  	INSERT INTO users(address,email,last_name,middle_name,name,password,phone_number,surname,id_genre)VALUES(''Kyoto japon calle falsa 123'',''seiya@saintseiya.com'',''Saori'',''de'',''Seiya'',
	  	''$2a$10$/FEiF3rIDCCqexuVPBhXnuQTuu0FxCCUpzoQXKOfoWtC2IUMT5UMm'',234234234234,''Caballero Pegaso'',1);
	  END IF;
 END;
' LANGUAGE plpgsql; 

SELECT insert_users_s();


CREATE OR REPLACE function insert_userrole_s()
RETURNS VOID 
AS '
DECLARE
	userrole integer;
BEGIN 
	  SELECT COUNT(*) INTO userrole FROM user_role;	  
	  IF userrole = 0 THEN
	  	INSERT INTO user_role(id_user,id_role)VALUES(1,1);
	  END IF;
 END;
' LANGUAGE plpgsql; 

SELECT insert_userrole_s();



